// import RNLanguages from 'react-native-languages'
import i18n from 'i18n-js'
import moment from 'moment'
import 'moment/locale/vi'

import en from './translations/en.json'
import ja from './translations/ja.json'

i18n.locale = 'en'
i18n.fallbacks = true
i18n.translations = { en, ja }

moment.locale('en')

export default i18n