const fonts = {
  system: 'System',
};
export default fonts;
