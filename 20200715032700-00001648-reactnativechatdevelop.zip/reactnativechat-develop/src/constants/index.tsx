export const FACEBOOK = 'FACEBOOK';

export const EMAIL = 'EMAIL';
export const PASSWORD = 'PASSWORD';

export const EMAIL_ALREADY_IN_USE = 'auth/email-already-in-use';
export const NETWORK_REQUEST_FAILED = 'auth/network-request-failed';
export const INVALID_CREDENTIAL = 'auth/invalid-credential';
export const INVALID_EMAIL = 'auth/invalid-email';
export const OTHER_ERROR = 'Error';

// login
export const USER_NOT_FOUND = 'auth/user-not-found';
export const WRONG_PASSWORD = 'auth/wrong-password';

export const STATUS_IDLE = 'STATUS_IDLE';
export const STATUS_ERROR = 'STATUS_ERROR';
export const STATUS_SUCCESS = 'STATUS_SUCCESS';
export const STATUS_PROCESSING = 'STATUS_PROCESSING';

export const COLLECTION_REF = {
  USERS: 'users',
  MESSAGES: 'messages',
  GROUP_MESSAGES: 'group_messages',
};

export const PROFILE = {
  USER_ID: 'user_id', // user id return when user register
  FCM_TOKEN: 'fcm_token', // fcm token of device
  USER_NAME: 'user_name',
  EMAIL: 'email',
  AVATAR: 'avatar',
  CREATE_DATE: 'create_date',
};
