export const FCM_TOKEN = 'fcmtoken';
