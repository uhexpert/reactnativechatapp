import {fork} from 'redux-saga/effects';
import ScreenSagas from './screens/sagas';
import ApiSaga from './api/saga';
import ModuleSagas from './api/modules/saga';

export default function* rootSaga() {
  yield fork(ScreenSagas);
  yield fork(ApiSaga);
  // api module
  yield fork(ModuleSagas);
}
