import { combineReducers } from 'redux'

import * as statusConst from 'constants'
import * as actionTypes from './actionTypes'
import ModulesReducers from './modules/reducer'

const INITIAL_STATE = {}

interface NextActionsObject {
  type: string
}

interface ActionObject {
  nextAction: NextActionsObject
  type: string
  isShowLoading: boolean
  error: object
}

const StatusReducer = (state = INITIAL_STATE, action: ActionObject) => {
  const newState = Object.assign({}, state)
  switch (action.type) {
    case actionTypes.REQUEST_IDLE:
      {
        const { nextAction } = action
        if (nextAction !== null && typeof nextAction.type !== 'undefined') {
          newState[nextAction.type] = {
            status: statusConst.STATUS_IDLE
          }
        }
      }
      break
    case actionTypes.REQUEST_PROCESSING:
      {
        const { nextAction } = action
        if (nextAction !== null && typeof nextAction.type !== 'undefined') {
          newState[nextAction.type] = {
            status: statusConst.STATUS_PROCESSING,
            isShowLoading: action.isShowLoading
          }
        }
      }
      break
    case actionTypes.REQUEST_SUCCESS:
      {
        const { nextAction } = action
        if (nextAction !== null && typeof nextAction.type !== 'undefined') {
          newState[nextAction.type] = {
            status: statusConst.STATUS_SUCCESS
          }
        }
      }
      break
    case actionTypes.REQUEST_ERROR:
      {
        const { nextAction } = action
        if (nextAction !== null && typeof nextAction.type !== 'undefined') {
          newState[nextAction.type] = {
            status: statusConst.STATUS_ERROR,
            error: action.error
          }
        }
      }
      break
    default:
      return newState
  }
  return newState
}

export default combineReducers({
  status: StatusReducer,
  database: ModulesReducers
})