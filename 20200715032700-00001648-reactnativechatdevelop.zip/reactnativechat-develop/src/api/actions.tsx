import * as actions from './actionTypes'

export const requestIdle = (nextAction: object) => {
  return {
    type: actions.REQUEST_IDLE,
    nextAction
  }
}

export const createRequestAPI = (nextAction: object, processMethod: (param: any) => Promise<{}>, param: object, isShowLoading = true) => {
  return {
    type: actions.REQUEST_PROCESSING,
    isShowLoading,
    nextAction,
    param,
    processMethod
  }
}

export const requestSuccess = (nextAction: object) => {
  return {
    type: actions.REQUEST_SUCCESS,
    nextAction
  }
}

export const requestFail = (nextAction: object, error: object) => {
  return {
    type: actions.REQUEST_ERROR,
    nextAction,
    error
  }
}