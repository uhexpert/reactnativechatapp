import {takeEvery, put, call} from 'redux-saga/effects';
import * as actionTypes from './actionTypes';
import {requestSuccess, requestFail} from './actions';

// FETCH_USERS
export function* handleRequest(action) {
  const {nextAction, processMethod, param} = action;
  try {
    if (
      nextAction === null ||
      typeof nextAction === 'undefined' ||
      processMethod === null ||
      typeof processMethod === 'undefined'
    ) {
      throw Error('Invalid request format');
    }

    const data = yield call(processMethod, param);
    yield put(requestSuccess(nextAction));
    yield put(Object.assign({}, nextAction, {data}));
  } catch (error) {
    // console.error(error);
    yield put(requestFail(nextAction, error));
  }
}
export default function* rootSaga() {
  yield takeEvery(actionTypes.REQUEST_PROCESSING, handleRequest);
}
