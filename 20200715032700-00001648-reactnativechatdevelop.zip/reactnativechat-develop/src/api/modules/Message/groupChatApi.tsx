import {eventChannel} from 'redux-saga';
import firestore from '@react-native-firebase/firestore';
import {COLLECTION_REF} from 'constants/index';

export const subcriberGroupMessages = () => {
  return eventChannel((emiter) => {
    const listener = firestore()
      .collection(COLLECTION_REF.GROUP_MESSAGES)
      .orderBy('createdAt', 'desc')
      .limit(15)
      .onSnapshot((snapshot) => {
        const messages: Array = [];
        snapshot.forEach((doc) => {
          const message = doc.data();
          messages.push({
            id: doc.id,
            ...message,
          });
        });
        emiter(messages);
      });

    const unsubscribe = () => {
      listener();
    };
    return unsubscribe;
  });
};

export const postGroupMessage = (message) => {
  return firestore().collection(COLLECTION_REF.GROUP_MESSAGES).add(message);
};

export const fetchGroupMessages = (params) => {
  const {lastMessage} = params;

  const ref = firestore()
    .collection(COLLECTION_REF.GROUP_MESSAGES)
    .orderBy('createdAt', 'desc')
    .startAfter(lastMessage.createdAt)
    .limit(15);

  return new Promise((resolve, reject) => {
    ref
      .get()
      .then((messages) => {
        const list: any = [];
        messages.forEach((doc) => {
          list.push({...doc.data(), id: doc.id});
        });
        resolve(list);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
