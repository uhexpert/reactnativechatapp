import {eventChannel} from 'redux-saga';
import {firebaseDB} from './config';

export const getReference = (roomId) => {
  const ref = `room/${roomId}/messages`;
  return firebaseDB.ref(ref.toString());
};

export const fetchMessageChatApi = (param) => {
  const {roomId} = param;
  return eventChannel((emiter) => {
    const reference = getReference(roomId);
    reference.limitToLast(100).on('value', (snapshot) => {
      const messages: any = [];
      if (!(snapshot.val() === undefined || snapshot.val() === null)) {
        const data = snapshot.val();
        const keys = Object.keys(data);
        keys.forEach((key) => {
          messages.push(data[key]);
        });
      }
      emiter(messages.reverse());
    });

    const unsubscribeChannel = () => {
      reference.off();
    };
    return unsubscribeChannel;
  });
};

export const fetchRoomChat = (param) => {
  const {userId} = param;
  return eventChannel((emiter) => {
    const reference = firebaseDB
      .ref(`users/${userId}`)
      .orderByChild('createTime')
      .limitToFirst(100);
    reference.on('value', (snapshot) => {
      const rooms: any = [];
      if (!(snapshot.val() === undefined || snapshot.val() === null)) {
        const data = snapshot.val();
        const keys = Object.keys(data);
        let index = 0;
        keys.forEach((key) => {
          rooms.push({...data[key], key: index});
          index += 1;
        });
      }
      emiter(rooms);
    });

    const unsubscribeChannel = () => {
      reference.off();
    };
    return unsubscribeChannel;
  });
};

export const postMessageChat = (param) => {
  // return null
  return new Promise((resolve, reject) => {
    const {
      messages,
      tokenId,
      roomId,
      partnerName,
      partnerAvatar,
      partnerTokenId,
    } = param;

    const userIds = roomId.split('_');
    const userId = messages[0].user._id;
    const messageText = messages[0].text;
    const createTime = Date.now();
    const avatar0 =
      userId === userIds[0] ? partnerAvatar : messages[0].user.avatar;
    const avatar1 =
      userId === userIds[1] ? partnerAvatar : messages[0].user.avatar;
    const partnerName0 =
      userId === userIds[0] ? partnerName : messages[0].user.name;
    const partnerName1 =
      userId === userIds[1] ? partnerName : messages[0].user.name;
    const tokenId0 = userId === userIds[0] ? tokenId : partnerTokenId;
    const tokenId1 = userId === userIds[1] ? tokenId : partnerTokenId;
    getReference(roomId)
      .push(messages[0])
      .then(() => {
        const updates = {};
        // if (userId === userIds[1]) {
        updates[`users/${userIds[0]}/${userIds[1]}`] = {
          partnerId: userIds[1],
          createTime,
          messageText,
          avatar: avatar0 === undefined ? '' : avatar0,
          readed: userId === userIds[1] ? false : true,
          name: partnerName0,
          tokenId: tokenId0,
        };
        // } else {
        updates[`users/${userIds[1]}/${userIds[0]}`] = {
          partnerId: userIds[0],
          createTime,
          messageText,
          avatar: avatar1 === undefined ? '' : avatar1,
          readed: userId === userIds[0] ? false : true,
          name: partnerName1,
          tokenId: tokenId1 || '',
        };
        // }
        firebaseDB
          .ref()
          .update(updates)
          .then(() => {
            resolve(messages[0]);
          })
          .catch((error1) => {
            reject(error1);
          });
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const updateMessageChat = (param) => {
  // return null
  return new Promise((resolve, reject) => {
    const {partnerId, userId, room} = param;
    const updates = {};
    updates[`users/${userId}/${partnerId}`] = {...room, readed: true};
    firebaseDB
      .ref()
      .update(updates)
      .then(() => {
        resolve(param);
      })
      .catch((error1) => {
        reject(error1);
      });
  });
};

export const initRoomId = (userId, partnerId) => {
  const roomIds = [];
  roomIds.push(userId);
  roomIds.push(partnerId);
  roomIds.sort();
  return roomIds.join('_');
};

export const deleteMessageChat = (param) => {
  // return null
  return new Promise((resolve, reject) => {
    const {partnerId, userId} = param;
    firebaseDB
      .ref(`users/${userId}/${partnerId}`)
      .remove()
      .then(() => {
        // const roomId = initRoomId(partnerId, userId)
        // firebaseDB.ref(`room/${roomId}`).remove().then(() => {
        resolve(param);
        // })
      })
      .catch((error1) => {
        reject(error1);
      });
  });
};
