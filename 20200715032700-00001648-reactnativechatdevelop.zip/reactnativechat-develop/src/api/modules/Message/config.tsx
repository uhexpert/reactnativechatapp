/* global __DEV__ */
import firebase from 'firebase';

/** @format */

let config = {
  apiKey: 'AIzaSyANhfqMnXFsiY4P4-KRW13bPk-JuPyXdFQ',
  authDomain: 'reactnative-d5741.firebaseapp.com',
  databaseURL: 'https://reactnative-d5741.firebaseio.com',
  projectId: 'reactnative-d5741',
  storageBucket: 'reactnative-d5741.appspot.com',
  messagingSenderId: '207858613098',
  appId: '1:207858613098:web:d16b1ab9d008845b234313',
};
/** @format */
if (__DEV__) {
  config = {
    apiKey: 'AIzaSyANhfqMnXFsiY4P4-KRW13bPk-JuPyXdFQ',
    authDomain: 'reactnative-d5741.firebaseapp.com',
    databaseURL: 'https://reactnative-d5741.firebaseio.com',
    projectId: 'reactnative-d5741',
    storageBucket: 'reactnative-d5741.appspot.com',
    messagingSenderId: '207858613098',
    appId: '1:207858613098:web:d16b1ab9d008845b234313',
  };
}

const app = firebase.initializeApp(config);
const firebaseDB = app.database();
export {app, firebaseDB};
