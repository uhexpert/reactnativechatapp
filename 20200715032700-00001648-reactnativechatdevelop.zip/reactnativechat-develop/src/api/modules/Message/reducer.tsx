import * as actions from './actionTypes';

const INITIAL_STATE = {
  messages: [],
  groupMessages: [],
  rooms: [],
};

export default (state = INITIAL_STATE, action) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case actions.MESSAGE_CHAT_SUBCRIBE_DONE:
      newState.messages = [...action.data];
      break;
    case actions.ROOM_CHAT_SUBCRIBE_DONE:
      newState.rooms = [
        ...action.data.sort(
          (a, b) => parseFloat(a.createTime) - parseFloat(b.createTime) < 0,
        ),
      ];
      break;
    // Chat group
    case actions.GROUP_MESSAGE_SUBSCRIBE_DONE:
      newState.groupMessages = [...action.data];
      break;
    case actions.FETCH_MESSAGE_GROUP_CHAT:
      newState.groupMessages = [...newState.groupMessages, ...action.data];
      break;
    default:
      return state;
  }
  return newState;
};
