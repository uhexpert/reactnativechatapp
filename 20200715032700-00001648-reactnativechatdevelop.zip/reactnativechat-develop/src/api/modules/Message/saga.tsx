import {
  call,
  put,
  select,
  take,
  takeLatest,
  cancelled,
} from 'redux-saga/effects';
import {getIsLogin} from 'api/modules/Account/selectors';

import * as actionTypes from './actionTypes';
import * as api from './api';
import * as groupChatApi from './groupChatApi';

export function* subscribeMessageChat(action) {
  const roomId = action.data;
  const isLogin = yield select(getIsLogin);
  if (isLogin) {
    const channel = yield call(api.fetchMessageChatApi, {roomId});

    while (true) {
      try {
        const data = yield take(channel);
        yield put({
          type: actionTypes.MESSAGE_CHAT_SUBCRIBE_DONE,
          data,
        });
      } catch (err) {
        channel.close();
      } finally {
        if (yield cancelled()) {
          channel.close();
        }
      }
    }
  }
}

export function* subscribeRoomChat(action) {
  const userId = action.data;
  const isLogin = yield select(getIsLogin);
  if (isLogin) {
    const channel = yield call(api.fetchRoomChat, {userId});

    while (true) {
      try {
        const data = yield take(channel);
        yield put({
          type: actionTypes.ROOM_CHAT_SUBCRIBE_DONE,
          data,
        });
      } catch (err) {
        channel.close();
      } finally {
        if (yield cancelled()) {
          channel.close();
        }
      }
    }
  }
}

export function* subscribeGroupMessages() {
  const isLogin = yield select(getIsLogin);
  if (isLogin) {
    const channel = yield call(groupChatApi.subcriberGroupMessages);

    while (true) {
      try {
        const data = yield take(channel);
        yield put({
          type: actionTypes.GROUP_MESSAGE_SUBSCRIBE_DONE,
          data,
        });
      } catch (err) {
        channel.close();
      } finally {
        if (yield cancelled()) {
          channel.close();
        }
      }
    }
  }
}

export default function* rootSaga() {
  yield takeLatest(actionTypes.ROOM_CHAT_SUBCRIBE, subscribeRoomChat);
  yield takeLatest(actionTypes.MESSAGE_CHAT_SUBCRIBE, subscribeMessageChat);
  yield takeLatest(actionTypes.GROUP_MESSAGE_SUBSCRIBE, subscribeGroupMessages);
}
