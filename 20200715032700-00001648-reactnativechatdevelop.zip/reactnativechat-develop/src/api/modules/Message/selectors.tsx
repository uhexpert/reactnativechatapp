export const getMessages = (state) => state.api.database.message.messages;
export const getGroupMessages = (state) =>
  state.api.database.message.groupMessages;
export const getRooms = (state) => state.api.database.message.rooms;
