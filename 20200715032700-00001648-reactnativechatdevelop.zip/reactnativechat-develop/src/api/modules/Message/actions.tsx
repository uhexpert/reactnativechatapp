import {createRequestAPI} from 'api/actions';
import * as actionType from './actionTypes';
import * as api from './api';
import * as groupApi from './groupChatApi';
/* eslint-disable import/prefer-default-export */
export const callFetchMessageChat = (data) => {
  return {
    type: actionType.MESSAGE_CHAT_SUBCRIBE,
    data,
  };
};

export const callFetchRoomChat = (data) => {
  return {
    type: actionType.ROOM_CHAT_SUBCRIBE,
    data,
  };
};

export const callPostMessageChat = (data) => {
  const nextAction = {
    type: actionType.POST_CHAT_MESSAGES,
  };
  return createRequestAPI(nextAction, api.postMessageChat, {...data});
};

export const callUpdateMessageChat = (data) => {
  const nextAction = {
    type: actionType.UPDATE_CHAT_MESSAGES,
  };
  return createRequestAPI(nextAction, api.updateMessageChat, {...data});
};

export const callDeleteMessageChat = (data) => {
  const nextAction = {
    type: actionType.DELETE_CHAT_MESSAGES,
  };
  return createRequestAPI(nextAction, api.deleteMessageChat, {...data});
};

// Group chat
export const callSubcriberGroupMessages = () => {
  return {
    type: actionType.GROUP_MESSAGE_SUBSCRIBE,
  };
};

export const callPostGroupMessage = (data) => {
  const nextAction = {
    type: actionType.POST_MESSAGE_GROUP_CHAT,
  };
  return createRequestAPI(nextAction, groupApi.postGroupMessage, {...data});
};

export const callFetchGroupMessages = (params: object) => {
  const nextAction = {
    type: actionType.FETCH_MESSAGE_GROUP_CHAT,
  };
  return createRequestAPI(nextAction, groupApi.fetchGroupMessages, {...params});
};
