import {fork} from 'redux-saga/effects';
import ProfileSaga from './Profile/saga';

export default function* rootSaga() {
  yield fork(ProfileSaga);
}
