import {combineReducers} from 'redux';
import ProfileReducer from './Profile/reducer';
import PartnerReducer from './Partner/reducer';

export default combineReducers({
  profile: ProfileReducer,
  partner: PartnerReducer,
});
