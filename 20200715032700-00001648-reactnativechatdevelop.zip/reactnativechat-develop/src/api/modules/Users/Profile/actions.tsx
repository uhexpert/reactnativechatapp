import {createRequestAPI} from 'api/actions';
import * as actionType from './actionTypes';
import * as api from './api';

/* ------PROFILE----- */
export const callSubscibeProfile = (userId: string) => {
  const action = {
    type: actionType.USERS_PROFILE_SUBSCRIBE,
    userId,
  };
  return createRequestAPI(action, api.subscribeProfile, {userId});
};

export const callPostSetProfile = (params: object) => {
  const action = {
    type: actionType.USERS_POST_SET_PROFILE,
  };
  return createRequestAPI(action, api.postSetProfile, params);
};

export const callDeleteDatabaseUser = (userId: string) => {
  const action = {
    type: actionType.DELETE_DATABASE_USER,
  };
  return createRequestAPI(action, api.deleteDatabaseUser, {userId});
};

export const callFetchAllUsers = (userId) => {
  return {
    type: actionType.USERS_SUBSCRIBE,
    userId,
  };
};
