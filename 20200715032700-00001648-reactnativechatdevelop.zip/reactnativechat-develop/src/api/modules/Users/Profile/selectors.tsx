import {PROFILE} from 'constants/index';
interface StateObject {
  [field: string]: any;
}

export const getUserAvatar = (state: StateObject) =>
  state.api.database.users.profile[PROFILE.AVATAR];
export const getUserEmail = (state: StateObject) =>
  state.api.database.users.profile[PROFILE.EMAIL];
export const getUserName = (state: StateObject) =>
  state.api.database.users.profile[PROFILE.USER_NAME];
export const getFcmToken = (state: StateObject) =>
  state.api.database.users.profile[PROFILE.FCM_TOKEN];
export const getProfile = (state: StateObject) =>
  state.api.database.users.profile;

export const getUsers = (state: StateObject) =>
  state.api.database.users.profile.users;
