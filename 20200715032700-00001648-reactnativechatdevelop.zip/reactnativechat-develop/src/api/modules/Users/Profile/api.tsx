import firestore from '@react-native-firebase/firestore';
import {eventChannel} from 'redux-saga';

import {
  COLLECTION_REF,
  STATUS_SUCCESS,
  STATUS_ERROR,
  PROFILE,
} from 'constants/index';

var listenerUsersChange: any = null;

export const validateObject = (object) => {
  const data = {};
  Object.entries(object).forEach(([key, value]) => {
    if (value !== undefined) data[key] = value;
  });
  return data;
};

interface ParamObject {
  userId: string;
}
export const subscribeProfile = (param: ParamObject) => {
  const {userId} = param;
  return new Promise((resolve, reject) => {
    firestore()
      .collection(COLLECTION_REF.USERS)
      .doc(userId)
      .get()
      .then((doc) => {
        if (doc.exists) {
          const data = validateObject(doc.data());
          resolve(Object.assign({}, data));
        } else {
          resolve({
            [PROFILE.AVATAR]:
              'https://i.pinimg.com/originals/bf/25/c7/bf25c7c4e731fd8e983ccb14f6c9426f.jpg',
            [PROFILE.USER_NAME]: 'USER',
            [PROFILE.EMAIL]: '',
          });
        }
      })
      .then(() => {
        reject();
      });
  });
};

export const postSetProfile = (params: ParamObject) => {
  return new Promise((resolve, reject) => {
    const {userId} = params;
    const data = {...params};
    delete data.userId;
    firestore()
      .collection(COLLECTION_REF.USERS)
      .doc(userId.toString())
      .set(data, {merge: true})
      .then(() => {
        firestore()
          .collection(COLLECTION_REF.USERS)
          .doc(userId.toString())
          .get()
          .then((doc) => {
            resolve(doc.data());
          });
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const deleteDatabaseUser = (param: ParamObject) => {
  return new Promise((resolve, reject) => {
    const {userId} = param;
    firestore()
      .collection(COLLECTION_REF.USERS)
      .doc(userId)
      .set({idDeleted: true})
      .then(() => {
        resolve(STATUS_SUCCESS);
      })
      .catch(() => {
        reject(STATUS_ERROR);
      });
  });
};

// get all user
export const getAllUser = (params) => {
  return eventChannel((emiter) => {
    // unsubcribe before listen new event
    unSubcriberUsers();
    // new subcriber
    listenerUsersChange = firestore()
      .collection(COLLECTION_REF.USERS)
      .orderBy('create_date', 'desc')
      .limit(15)
      .onSnapshot((snapshot) => {
        const array: any = [];
        snapshot.forEach((user) => {
          const data = user.data();
          const id = user.id;
          if (params.userId !== id) array.push({id, ...data});
        });
        emiter(array);
      });
    return listenerUsersChange;
  });
};

export const unSubcriberUsers = () => {
  if (listenerUsersChange !== null) {
    listenerUsersChange();
    listenerUsersChange = null;
  }
};
