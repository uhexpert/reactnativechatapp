import {
  takeLatest,
  call,
  put,
  select,
  take,
  cancelled,
  cancel,
  race,
} from 'redux-saga/effects';
import {getIsLogin} from 'api/modules/Account/selectors';

import * as actionTypes from './actionTypes';
import * as api from './api';

interface ParamObject {
  userId: string;
}

export function* subscribeUsers(param: ParamObject) {
  const isLogin = yield select(getIsLogin);
  if (isLogin) {
    const channel = yield call(api.getAllUser, param);

    while (true) {
      try {
        const data = yield take(channel);
        yield put({
          type: actionTypes.USERS_SUBSCRIBE_DONE,
          data,
        });
      } catch (err) {
        channel.close();
      } finally {
        if (yield cancelled()) {
          channel.close();
        }
      }
    }
  }
}

export default function* rootSaga() {
  yield takeLatest(actionTypes.USERS_SUBSCRIBE, subscribeUsers);
}
