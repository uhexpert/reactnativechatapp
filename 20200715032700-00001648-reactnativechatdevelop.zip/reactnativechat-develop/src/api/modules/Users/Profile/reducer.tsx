import * as actions from './actionTypes';

const INITIAL_STATE = {
  users: [],
};

interface ActionObject {
  type: string;
  data: object;
}
export default (state = INITIAL_STATE, action: ActionObject) => {
  switch (action.type) {
    /* SUCCESS */
    case actions.USERS_PROFILE_SUBSCRIBE:
    case actions.USERS_POST_SET_PROFILE:
      return Object.assign({}, state, action.data);
    case actions.USERS_SUBSCRIBE_DONE:
      return Object.assign({}, state, {users: action.data});
    default:
      return state;
  }
};
