import {createRequestAPI} from 'api/actions';
import * as actionType from './actionTypes';
import * as api from './api';

export const callFetchPartner = (data) => {
  const nextAction = {
    type: actionType.FETCH_PARTNER_PROFILE,
  };
  return createRequestAPI(nextAction, api.fetchPartner, {...data});
};
