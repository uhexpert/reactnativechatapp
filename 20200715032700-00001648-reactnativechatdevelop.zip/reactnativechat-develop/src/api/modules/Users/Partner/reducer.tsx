import * as actions from './actionTypes';

const INITIAL_STATE = {
  partner: {},
};

interface ActionObject {
  type: string;
  data: object;
}
export default (state = INITIAL_STATE, action: ActionObject) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case actions.FETCH_PARTNER_PROFILE:
      newState.partner = action.data;
      break;

    default:
      return state;
  }
  return newState;
};
