import firestore from '@react-native-firebase/firestore';
import {eventChannel} from 'redux-saga';

import {
  COLLECTION_REF,
  STATUS_SUCCESS,
  STATUS_ERROR,
  PROFILE,
} from 'constants/index';

export const fetchPartner = (params: any) => {
  return new Promise((resolve, reject) => {
    const {partnerId} = params;
    firestore()
      .collection(COLLECTION_REF.USERS)
      .doc(partnerId.toString())
      .get()
      .then((doc) => {
        resolve({
          id: doc.id,
          ...doc.data(),
        });
      })
      .catch((error) => {
        console.log('error', error);
        reject(error);
      });
  });
};
