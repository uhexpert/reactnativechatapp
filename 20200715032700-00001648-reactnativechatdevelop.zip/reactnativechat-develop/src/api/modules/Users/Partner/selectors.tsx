export const getPartner = (state: any) =>
  state.api.database.users.partner.partner;
