import {takeEvery, put, take, select} from 'redux-saga/effects';
import * as accountSlectors from 'api/modules/Account/selectors';
import * as profileActions from 'api/modules/Users/Profile/actions';
import {PROFILE} from 'constants/index';

export function* updateAvatarProfile(action) {
  const userId = yield select((state) => accountSlectors.getUserId(state));
  const urlImage = action.data;

  yield put(
    profileActions.callPostSetProfile({userId, [PROFILE.AVATAR]: urlImage}),
  );
}

export default function* rootSaga() {
  yield takeEvery('UPLOAD_IMAGE_AVATAR', updateAvatarProfile);
}
