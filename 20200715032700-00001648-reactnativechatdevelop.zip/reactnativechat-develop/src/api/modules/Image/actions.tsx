import * as actionTypes from './actionTypes';
import {createRequestAPI} from '../../actions';
import * as api from './api';

/* ==========Call API========== */
export const callUploadImageAvata = (params: {}) => {
  const nextAction = {
    type: actionTypes.UPLOAD_IMAGE_AVATAR,
  };
  return createRequestAPI(nextAction, api.uploadImageAvata, {...params});
};

export const callUploadImageSingleChat = (params) => {
  const nextAction = {
    type: actionTypes.UPLOAD_IMAGE_SINGLE_CHATING,
  };
  return createRequestAPI(nextAction, api.uploadImageChatting, {...params});
};

export const callUploadImageGroupChat = (params) => {
  const nextAction = {
    type: actionTypes.UPLOAD_IMAGE_GROUP_CHATING,
  };
  return createRequestAPI(nextAction, api.uploadImageChatting, {...params});
};
