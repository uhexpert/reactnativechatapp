import * as actionTypes from './actionTypes';

interface ActionObject {
  type: string;
}

const INITIAL_STATE = {
  avatar: '',
};

const ImageUploadReducer = (state = INITIAL_STATE, action: ActionObject) => {
  const newState = {...state};
  switch (action.type) {
    case actionTypes.UPLOAD_IMAGE_AVATAR:
      newState.avatar = action.data;
      break;
    default:
      return state;
  }
  return newState;
};
export default ImageUploadReducer;
