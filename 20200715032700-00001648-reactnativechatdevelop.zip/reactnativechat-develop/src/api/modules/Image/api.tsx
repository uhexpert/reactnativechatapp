import {Platform} from 'react-native';
import storage from '@react-native-firebase/storage';
// import RNFetchBlob from 'rn-fetch-blob';
import ImageResizer from 'react-native-image-resizer';

// upload use firebase root
export const uploadImageAvata = (param) => {
  const {mime = 'application/octet-stream', userId} = param;
  return new Promise((resolve, reject) => {
    return ImageResizer.createResizedImage(param.uri, 800, 600, 'JPEG', 50)
      .then(({uri}) => {
        const fileSource =
          Platform.OS === 'ios' ? uri.replace('file://', '') : uri;
        const imageRef = storage().ref(`images/${userId}`).child('profile.png');
        // uploads file
        return imageRef
          .putFile(fileSource)
          .then(() => {
            return imageRef.getDownloadURL();
          })
          .then((url) => {
            resolve(url);
          })
          .catch((error) => {
            reject(error);
          });
      })
      .catch((error2) => {
        // console.error(error2);
        // get default url
        resolve(param.uri);
      });
  });
};

export const uploadImageChatting = (param) => {
  const {mime = 'application/octet-stream', userId, timestamp} = param;
  return ImageResizer.createResizedImage(param.uri, 800, 600, 'JPEG', 50)
    .then(({uri}) => {
      return new Promise((resolve, reject) => {
        const uploadUri =
          Platform.OS === 'ios' ? uri.replace('file://', '') : uri;
        // let uploadBlob = null
        const imageRef = storage()
          .ref(`images/${userId}/chatting`)
          .child(`${timestamp}.png`);
        return imageRef
          .putFile(uploadUri)
          .then(() => {
            return imageRef.getDownloadURL();
          })
          .then((url) => {
            resolve(url);
          })
          .catch((error) => {
            reject(error);
          });
      });
    })
    .catch(() => {
      return param.uri;
    });
};
