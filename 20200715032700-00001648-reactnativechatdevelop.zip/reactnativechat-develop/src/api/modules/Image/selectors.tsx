interface StateObject {
  api: {
    database: {
      images: {
        imagesMeal: string
      }
    }
  }
}
export const getImagesMeal = (state: StateObject) => state.api.database.images.imagesMeal