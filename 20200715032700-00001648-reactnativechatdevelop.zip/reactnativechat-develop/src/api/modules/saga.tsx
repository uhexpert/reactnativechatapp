import {fork} from 'redux-saga/effects';
import UsersSaga from './Users/saga';
import MessageSaga from './Message/saga';
import AccountSaga from './Account/saga';
import ImageSaga from './Image/saga';

export default function* rootSaga() {
  yield fork(UsersSaga);
  yield fork(MessageSaga);
  yield fork(AccountSaga);
  yield fork(ImageSaga);
}
