import {combineReducers} from 'redux';
import AccountReducer from './Account/reducer';
import mesReducer from './Message/reducer';
import UsersReducer from './Users/reducer';
import ImageReducer from './Image/reducer';

export default combineReducers({
  users: UsersReducer,
  account: AccountReducer,
  message: mesReducer,
  images: ImageReducer,
});
