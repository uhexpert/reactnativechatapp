import * as actions from './actionTypes';

const INITIAL_STATE = {
  isLoginSuccess: false,
  isResetPasswordSuccess: false,
  providerType: '',
  info: {},
};

export default (state = INITIAL_STATE, action) => {
  const newState = {...state};
  switch (action.type) {
    case actions.ACCOUNT_FETCH_INFO:
      newState.info = action.data;
      break;
    case actions.ACCOUNT_POST_LOGIN:
      if (typeof action.data === 'undefined' || action.data === null) {
        return newState;
      }
      newState.isLoginSuccess = action.data.isLoginSuccess;
      newState.providerType = action.data.providerType;
      break;
    case actions.ACCOUNT_POST_LOGOUT:
      newState.isLoginSuccess = false;
      if (!newState.isLoginSuccess) {
        newState.info = {};
        newState.providerType = '';
      }
      break;
    case actions.ACCOUNT_REQUEST_LOGIN_AGAIN:
      newState.isLoginSuccess = false;
      break;
    case actions.ACCOUNT_POST_REGISTER:
      if (typeof action.data === 'undefined' || action.data === null) {
        return newState;
      }
      newState.isLoginSuccess = action.data.isLoginSuccess;
      newState.providerType = 'EmailPassword';
      newState.info = action.data.info;
      break;
    case actions.ACCOUNT_POST_LOGIN_ANONYMOUS:
      if (typeof action.data === 'undefined' || action.data === null) {
        return newState;
      }
      newState.isLoginSuccess = action.data.isLoginSuccess;
      newState.providerType = action.data.providerType;
      newState.info = action.data.info;
      break;
    case actions.ACCOUNT_PUT_PROFILE:
      newState.info = action.data;
      break;
    case actions.ACCOUNT_UPDATE_WITH_PROVIDER_TYPE:
      newState.providerType = action.data;
      break;
    case actions.ACCOUNT_SET_STATUS_USER_LOGIN:
      newState.isLoginSuccess = action.data;
      break;
    case actions.ACCOUNT_REQUEST_RESET_PASSWORD:
      if (action.data) {
        newState.isResetPasswordSuccess = true;
      }
      break;
    case actions.ACCOUNT_BACK_SCREEN_LOGIN:
      newState.isResetPasswordSuccess = false;
      break;
    case actions.ACCOUNT_RESET_STATUS:
      return {...state};
    default:
      return state;
  }
  return newState;
};
