interface StateObject {
  api: {
    database: {
      account: {
        providerType: string
        info: {
          uid: string
          email: string
          photoURL: string
          displayName: string
        }
        isResetPasswordSuccess: boolean
        isLoginSuccess: boolean
      }
    }
  }
}
export const getProviderType = (state: StateObject) => state.api.database.account.providerType
export const getAccountInfo = (state: StateObject) => state.api.database.account.info
export const isResetPasswordSuccess = (state: StateObject) => state.api.database.account.isResetPasswordSuccess
export const getIsLogin = (state: StateObject) => state.api.database.account.isLoginSuccess
export const getUserId = (state: StateObject) => state.api.database.account.info.uid
export const getUserEmail = (state: StateObject) => state.api.database.account.info.email
export const getUserImageURL = (state: StateObject) => state.api.database.account.info.photoURL
export const getDisplayname = (state: StateObject) => state.api.database.account.info.displayName