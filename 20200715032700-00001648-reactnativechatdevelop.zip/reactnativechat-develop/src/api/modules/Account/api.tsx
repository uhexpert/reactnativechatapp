import auth from '@react-native-firebase/auth';

import getProvider from './Providers';

interface paramObject {
  providerType: string;
  email: string;
  userName: string;
  password: string;
  displayName: string;
  photoURL: string;
}
// Prepare Blob supportv
export const fetchAccountInfo = (params: paramObject) => {
  const {providerType} = params;
  return getProvider(providerType).getInfo();
};

export const requestLogin = (params: paramObject) => {
  const {providerType} = params;
  return getProvider(providerType).signIn(params);
};

export const requestSignOut = (params: paramObject) => {
  const {providerType} = params;
  // TODO: unsubscribe all
  return getProvider(providerType).signOut();
};

export const requestDeleteUser = (params: paramObject) => {
  const {providerType} = params;
  return getProvider(providerType).delete();
};

export const requestRegister = (param: paramObject) => {
  const result = {
    isLoginSuccess: false,
    providerType: 'EmailPassword',
    info: {},
  };
  return new Promise((resolve, reject) => {
    const {email, password} = param;
    auth()
      .createUserWithEmailAndPassword(email, password)
      .then((data) => {
        result.isLoginSuccess = true;
        result.info = data.user;
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const updateProfile = (param: paramObject) => {
  return new Promise((resolve, reject) => {
    const {displayName, photoURL} = param;
    const user = auth().currentUser;
    if (user) {
      user
        .updateProfile({
          displayName: displayName || user.displayName,
          photoURL: photoURL || user.photoURL,
        })
        .then(() => {
          resolve(auth().currentUser);
        })
        .catch((error) => {
          reject(error);
        });
    }
  });
};

export const requestResetPassword = (param: paramObject) => {
  return new Promise((resolve, reject) => {
    const {email} = param;
    auth()
      .sendPasswordResetEmail(email)
      .then(() => {
        resolve(true);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
