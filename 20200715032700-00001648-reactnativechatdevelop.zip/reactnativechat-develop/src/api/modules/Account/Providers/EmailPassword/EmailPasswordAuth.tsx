import FirebaseDBAuth from '../FirebaseDBAuth';
import auth from '@react-native-firebase/auth';
import * as config from '../config';

export default class EmailPasswordAuth {
  public firebase = new FirebaseDBAuth();

  public signIn = (userName: string, password: string) => {
    const signInResult = {...config.RESULT_TEMPLATE};
    return auth()
      .signInWithEmailAndPassword(userName, password)
      .then(() => {
        signInResult.isSuccess = true;
        return signInResult;
      });
  };

  public fetchAccountInfo = () => {
    return this.firebase.fetchAccountInfo() || {};
  };

  public signOut = () => {
    return this.firebase.signOut();
  };

  public deleteUser = () => {
    return this.firebase.deleteUser();
  };
}
