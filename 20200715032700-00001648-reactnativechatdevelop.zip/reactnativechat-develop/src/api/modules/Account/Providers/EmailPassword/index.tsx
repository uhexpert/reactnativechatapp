import EmailPasswordAuth from './EmailPasswordAuth';
import AccountProvider from '../Provider';

interface ParamsObject {
  userName: string;
  password: string;
}

class EmailPasswordProvider extends AccountProvider {
  constructor() {
    super();
  }

  public auth = new EmailPasswordAuth();

  public signIn = (params: ParamsObject) => {
    const {userName, password} = params;
    return new Promise((resolve, reject) => {
      this.auth
        .signIn(userName, password)
        .then((result: {isSuccess: boolean}) => {
          return resolve({
            isLoginSuccess: result.isSuccess,
            providerType: 'EmailPassword',
          });
        })
        .catch((error: object) => {
          return reject(error);
        });
    });
  };

  public getInfo = () => {
    return this.auth.fetchAccountInfo() || {};
  };

  public signOut = () => {
    console.log('LOGOUT imlement.....');

    return this.auth.signOut();
  };

  public delete = () => {
    return this.auth.deleteUser();
  };
}
export default new EmailPasswordProvider();
