import AnonymousAuth from './AnonymousAuth'
import AccountProvider from '../Provider'

class AnonymousAuthProvider extends AccountProvider {
  public auth = new AnonymousAuth()

  public signIn = () => {
    return new Promise((resolve, reject) => {
      this.auth.signIn().then((result: { isSuccess: boolean }) => {
        return resolve({ isLoginSuccess: result.isSuccess, providerType: 'Anonymous' })
      }).catch((error: object) => {
        return reject(error)
      })
    })
  }

  public getInfo = () => {
    return this.auth.fetchAccountInfo() || {}
  }

  public signOut = () => {
    return this.auth.signOut()
  }

  public delete = () => {
    return this.auth.deleteUser()
  }
}
export default new AnonymousAuthProvider()