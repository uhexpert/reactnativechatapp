import FirebaseDBAuth from '../FirebaseDBAuth';
import auth from '@react-native-firebase/auth';
import * as config from '../config';

export default class AnonymousAuth {
  public firebase = new FirebaseDBAuth();

  public signIn = () => {
    const signInResult = {...config.RESULT_TEMPLATE};
    return auth()
      .signInAnonymously()
      .then(() => {
        signInResult.isSuccess = true;
        return signInResult;
      });
  };

  public fetchAccountInfo = () => {
    return this.firebase.fetchAccountInfo() || {};
  };

  public signOut = () => {
    return this.firebase.signOut();
  };

  public deleteUser = () => {
    return this.firebase.deleteUser();
  };
}
