import {GoogleSignin} from 'react-native-google-signin';
import FirebaseDBAuth from '../FirebaseDBAuth';
import * as config from '../config';

export default class GoogleAuth {
  public firebase = new FirebaseDBAuth();
  constructor() {
    GoogleSignin.configure();
  }

  public signIn = () => {
    const signInResult = {...config.RESULT_TEMPLATE};
    return GoogleSignin.hasPlayServices()
      .then(() => {
        return GoogleSignin.signOut();
      })
      .then(() => {
        return GoogleSignin.signIn();
      })
      .then(() => {
        return GoogleSignin.getTokens();
      })
      .then((token) => {
        const credential = this.firebase.signUpWithGoogleAccountCredential(
          token.idToken,
          token.accessToken,
        );
        return this.firebase.signInWithCredential(credential);
      })
      .then(() => {
        signInResult.isSuccess = true;
        return signInResult;
      });
  };

  public fetchAccountInfo = () => {
    return this.firebase.fetchAccountInfo() || {};
  };

  public signOut = () => {
    return GoogleSignin.revokeAccess()
      .then(() => {
        return GoogleSignin.signOut();
      })
      .then(() => {
        return this.firebase.signOut();
      });
  };

  public deleteUser = () => {
    return this.firebase.deleteUser() || {};
  };
}
