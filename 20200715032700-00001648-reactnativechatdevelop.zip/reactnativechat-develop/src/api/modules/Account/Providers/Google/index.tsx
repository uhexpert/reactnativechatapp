import AccountProvider from '../Provider'
import GoogleAuth from './GoogleAuth'

class GoogleProvider extends AccountProvider {
  public auth = new GoogleAuth()

  public signIn = () => {
    return new Promise((resolve, reject) => {
      this.auth.signIn().then((result) => {
        return resolve({ isLoginSuccess: result.isSuccess, providerType: 'Google' })
      }).catch((error) => {
        return reject(error)
      })
    })
  }

  public getInfo = () => {
    return this.auth.fetchAccountInfo() || {}
  }

  public signOut = () => {
    return this.auth.signOut() || {}
  }

  public delete = () => {
    return this.auth.deleteUser() || {}
  }
}
export default new GoogleProvider()