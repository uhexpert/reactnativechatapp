import AccountProvider from '../Provider'
import TwitterAuth from './TwitterAuth'

class TwitterProvider extends AccountProvider {
  public auth = new TwitterAuth()

  public signIn = () => {
    return new Promise((resolve, reject) => {
      this.auth.signIn().then((result: { isSuccess: any; }) => {
        return resolve({ isLoginSuccess: result.isSuccess, providerType: 'Twitter' })
      }).catch((error: any) => {
        return reject(error)
      })
    })
  }

  public getInfo = () => {
    return this.auth.fetchAccountInfo() || {}
  }

  public signOut = () => {
    const currentUser = this.getInfo()
    if (!currentUser) { return true }
    return this.auth.signOut()
  }

  public delete = () => {
    return this.auth.deleteUser()
  }
}
export default new TwitterProvider()