import {NativeModules} from 'react-native';
import FirebaseDBAuth from '../FirebaseDBAuth';
import * as config from '../config';

const {RNTwitterSignIn} = NativeModules;
const TwitterKeys = {
  TWITTER_COMSUMER_KEY: 'io5wJPUTnp3WQ4Hbo4Xg7zLMb',
  TWITTER_CONSUMER_SECRET: '6KEVtY8k1DLrp0FUshvQA6ihUmkGNImF64bWV7SOvsXpopgdlp',
};

export default class TwitterAuth {
  public firebase = new FirebaseDBAuth();

  public signIn = () => {
    const signInResult = {...config.RESULT_TEMPLATE};
    RNTwitterSignIn.init(
      TwitterKeys.TWITTER_COMSUMER_KEY,
      TwitterKeys.TWITTER_CONSUMER_SECRET,
    );
    return this.signOut()
      .then(() => {
        return RNTwitterSignIn.logIn();
      })
      .then((currentAccessToken) => {
        const {authToken, authTokenSecret} = currentAccessToken;
        const credential = this.firebase.signUpWithTwitterAccountCredential(
          authToken,
          authTokenSecret,
        );
        return this.firebase.signInWithCredential(credential);
      })
      .then(() => {
        signInResult.isSuccess = true;
        return signInResult;
      });
  };

  public fetchAccountInfo = () => {
    return this.firebase.fetchAccountInfo() || {};
  };

  public signOut = () => {
    RNTwitterSignIn.init(
      TwitterKeys.TWITTER_COMSUMER_KEY,
      TwitterKeys.TWITTER_CONSUMER_SECRET,
    );
    RNTwitterSignIn.logOut();
    return this.firebase.signOut();
  };

  public deleteUser = () => {
    return this.firebase.deleteUser() || {};
  };
}
