export const RESULT_TEMPLATE = {
  isSuccess: false,
  data: {},
  error: {code: '', msg: ''},
};
