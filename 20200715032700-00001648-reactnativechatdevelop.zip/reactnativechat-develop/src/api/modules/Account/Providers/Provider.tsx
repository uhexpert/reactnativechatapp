export default class AccountProvider {
    public signIn = () => {
      throw Error('signIn_NOT_IMPLEMENT_YET')
    }

    public getInfo = () => {
      throw Error('getInfo_NOT_IMPLEMENT_YET')
    }

    public signOut = () => {
      throw Error('signOut_NOT_IMPLEMENT_YET')
    }

    public delete = () => {
      throw Error('delete_NOT_IMPLEMENT_YET')
    }

    public onCatchError = (error: object) => {
      // tslint:disable-next-line: no-console
      console.log('AccountProvider-onCatchError', error)
      // return error
    }
}