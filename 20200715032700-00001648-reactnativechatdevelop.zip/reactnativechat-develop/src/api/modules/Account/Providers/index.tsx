import AccountProvider from './Provider';
import EmailPasswordProvider from './EmailPassword';
import AnonymousAuthProvider from './Anonymous';
import FacebookProvider from './Facebook';
import TwitterProvider from './Twitter';
import GoogleProvider from './Google';

export default (providerType: string) => {
  switch (providerType) {
    case 'Anonymous':
      return AnonymousAuthProvider;
    case 'EmailPassword':
      return EmailPasswordProvider;
    // case 'Facebook':
    //   return FacebookProvider
    // case 'Twitter':
    //   return TwitterProvider
    // case 'Google':
    //   return GoogleProvider
    default:
      return new AccountProvider();
  }
};
