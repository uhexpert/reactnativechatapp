import {LoginManager, AccessToken} from 'react-native-fbsdk';
import FirebaseDBAuth from '../FirebaseDBAuth';
import * as config from '../config';

export default class FacebookAuth {
  public firebase = new FirebaseDBAuth();

  public signIn = () => {
    const signInResult = {...config.RESULT_TEMPLATE};
    this.signOut();
    return LoginManager.logInWithReadPermissions(['public_profile', 'email'])
      .then((result) => {
        if (result.isCancelled) {
          return false;
        }
        return AccessToken.getCurrentAccessToken();
      })
      .then((currentAccessToken) => {
        if (currentAccessToken === false) {
          throw new Error('USER_CANCELLED');
        }
        const credential = this.firebase.signUpWithFacebookAccountCredential(
          currentAccessToken.accessToken,
        );
        return this.firebase.signInWithCredential(credential);
      })
      .then(() => {
        signInResult.isSuccess = true;
        return signInResult;
      });
  };

  public fetchAccountInfo = () => {
    return this.firebase.fetchAccountInfo() || {};
  };

  public signOut = () => {
    LoginManager.logOut();
    return this.firebase.signOut();
  };

  public deleteUser = () => {
    return this.firebase.deleteUser();
  };
}
