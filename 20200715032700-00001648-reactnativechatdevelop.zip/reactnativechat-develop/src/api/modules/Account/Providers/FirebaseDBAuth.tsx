import auth from '@react-native-firebase/auth';
import * as config from './config';

interface ErrorObject {
  code: string;
  message: string;
}
export default class FirebaseDBAuth {
  public onCatchError = (error: ErrorObject) => {
    const result = {...config.RESULT_TEMPLATE};
    result.error.code = error.code;
    result.error.msg = error.message;
    return result;
  };

  public signUpWithFacebookAccountCredential = (accessToken: string) => {
    return auth.FacebookAuthProvider.credential(accessToken);
  };

  public signUpWithTwitterAccountCredential = (
    accessToken: string,
    authTokenSecret: string,
  ) => {
    return auth.TwitterAuthProvider.credential(accessToken, authTokenSecret);
  };

  public signUpWithGoogleAccountCredential = (
    idToken: string,
    accessToken: string,
  ) => {
    return auth.GoogleAuthProvider.credential(idToken, accessToken);
  };

  public signInWithCredential = (credential: string) => {
    return auth().signInWithCredential(credential);
  };

  public fetchAccountInfo = () => {
    return new Promise((resolve, reject) => {
      auth().onAuthStateChanged((user: any) => {
        if (user) {
          resolve(user);
        }
        resolve({});
      });
    });
  };

  public signOut = () => {
    const signOutResult = {...config.RESULT_TEMPLATE};
    return auth()
      .signOut()
      .then(() => {
        signOutResult.isSuccess = true;
        return signOutResult;
      })
      .catch(this.onCatchError);
  };

  public deleteUser = () => {
    const deleteUserResult = {...config.RESULT_TEMPLATE};
    const user = auth().currentUser;
    return new Promise((resolve, reject) => {
      if (user === null) {
        reject('User current is null.');
      } else {
        user
          .delete()
          .then(() => {
            deleteUserResult.isSuccess = true;
            return resolve(deleteUserResult);
          })
          .catch((error: ErrorObject) => {
            return reject(this.onCatchError(error));
          });
      }
    });
  };
}
