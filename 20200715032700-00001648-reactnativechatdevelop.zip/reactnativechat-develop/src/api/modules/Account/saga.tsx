import {takeLatest, select, put} from 'redux-saga/effects';
import LocalStorage from 'services/Storage';
// import NavigationServices from 'services/NavigationService';
// import * as Routes from 'navigator/routerName';

import * as actionTypes from './actionTypes';
import {
  callFetchAccountInfo,
  callRequestDeleteUser,
  resetStatusLogin,
} from './actions';
import * as selectors from './selectors';

// FETCH_USERS
export function* getProfileAfterLoginSuccess() {
  const providerType = yield select(selectors.getProviderType);

  // Save to storage
  LocalStorage.save({
    key: 'providerType',
    data: providerType || '',
  });
  console.log('callFetchAccountInfo');
  yield put(callFetchAccountInfo(providerType, {}));
}

export function* removeProviderTypeLocal() {
  // Save to storage
  LocalStorage.save({
    key: 'providerType',
    data: '',
  });
  yield put(resetStatusLogin());
}

export function* deleteAccount() {
  const providerType = yield select(selectors.getProviderType);

  yield put(callRequestDeleteUser(providerType, {}));

  setTimeout(() => {
    // NavigationServices.navigate(Routes.FIRST_LOGIN);
  }, 100);
}

export default function* rootSaga() {
  yield takeLatest(
    actionTypes.ACCOUNT_POST_REGISTER,
    getProfileAfterLoginSuccess,
  );
  yield takeLatest(actionTypes.ACCOUNT_POST_LOGIN, getProfileAfterLoginSuccess);
  yield takeLatest(
    actionTypes.ACCOUNT_POST_LOGIN_ANONYMOUS,
    getProfileAfterLoginSuccess,
  );
  yield takeLatest(actionTypes.ACCOUNT_POST_FEEDBBACK_WITHDREW, deleteAccount);
  yield takeLatest(actionTypes.ACCOUNT_POST_LOGOUT, removeProviderTypeLocal);
}
