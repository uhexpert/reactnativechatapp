import * as actionTypes from './actionTypes';
import {createRequestAPI, requestIdle} from '../../actions';
import * as api from './api';

/* ==========Call API========== */
export const callFetchAccountInfo = (
  providerType: string,
  params: {} | undefined,
) => {
  const nextAction = {
    type: actionTypes.ACCOUNT_FETCH_INFO,
  };
  return createRequestAPI(nextAction, api.fetchAccountInfo, {
    providerType,
    ...params,
  });
};

export const callRequestLogin = (providerType: string, params: {}) => {
  const nextAction = {
    type: actionTypes.ACCOUNT_POST_LOGIN,
  };
  return createRequestAPI(nextAction, api.requestLogin, {
    providerType,
    ...params,
  });
};

export const callRequestLogOut = (providerType: string, params: {}) => {
  const nextAction = {
    type: actionTypes.ACCOUNT_POST_LOGOUT,
  };
  return createRequestAPI(nextAction, api.requestSignOut, {
    providerType,
    ...params,
  });
};

export const callRequestDeleteUser = (providerType: string, params: {}) => {
  const nextAction = {
    type: actionTypes.ACCOUNT_POST_DELETE_USER,
  };
  return createRequestAPI(nextAction, api.requestDeleteUser, {
    providerType,
    ...params,
  });
};

export const callRequestRegister = (email: string, password: string) => {
  const action = {
    type: actionTypes.ACCOUNT_POST_REGISTER,
  };
  return createRequestAPI(action, api.requestRegister, {email, password});
};

export const callUpdateProfile = (info: object) => {
  const action = {
    type: actionTypes.ACCOUNT_PUT_PROFILE,
  };
  return createRequestAPI(action, api.updateProfile, info);
};

export const callRequestResetPassword = (email: string) => {
  const action = {
    type: actionTypes.ACCOUNT_REQUEST_RESET_PASSWORD,
  };
  return createRequestAPI(action, api.requestResetPassword, {email});
};

/* ==========Modify Redux State========== */
export const resetStatusLogin = () => {
  return {
    type: actionTypes.ACCOUNT_RESET_STATUS,
  };
};

export const updateAccountWithProviderType = (data: any) => {
  const action = {
    type: actionTypes.ACCOUNT_UPDATE_WITH_PROVIDER_TYPE,
    data,
  };
  return action;
};

export const setStatusUserLogin = (data: boolean) => {
  const action = {
    type: actionTypes.ACCOUNT_SET_STATUS_USER_LOGIN,
    data,
  };
  return action;
};

export const resetStatusResetPassword = () => {
  const action = {
    type: actionTypes.ACCOUNT_REQUEST_RESET_PASSWORD,
  };
  return requestIdle(action);
};

export const backScreenLogin = () => {
  return {
    type: actionTypes.ACCOUNT_BACK_SCREEN_LOGIN,
  };
};

export const requestReLoginAccount = () => {
  return {
    type: actionTypes.ACCOUNT_REQUEST_LOGIN_AGAIN,
  };
};
