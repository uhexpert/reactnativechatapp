interface StateObject {
  api: {
    status: object;
    database: object;
  };
}

export const getRequestStatus = (state: StateObject) => state.api.status;
export const getDatabase = (state: StateObject) => state.api.database;
