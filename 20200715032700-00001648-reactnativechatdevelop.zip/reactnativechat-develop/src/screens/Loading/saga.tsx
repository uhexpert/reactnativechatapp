import {put, takeLatest} from 'redux-saga/effects';
import {
  REQUEST_PROCESSING,
  REQUEST_ERROR,
  REQUEST_SUCCESS,
} from 'api/actionTypes';
import {
  ACCOUNT_POST_LOGOUT,
  ACCOUNT_POST_LOGIN,
  ACCOUNT_POST_REGISTER,
  ACCOUNT_POST_DELETE_USER,
} from 'api/modules/Account/actionTypes';
import {
  INITIALIZE_FINISHED,
  PROCESS_BACK_BUTTON_DEVICES,
} from 'screens/Launch/actionType';
import * as actions from './actions';

export function* hideLoadingView(action: any) {
  console.log('hideLoadingView', action);
  if (action.nextAction !== undefined) {
    if (action.type === REQUEST_ERROR) {
      yield put(actions.showLoadingAction(false));
    } else {
      let ignoreAction = false;
      ignoreAction =
        ignoreAction || action.nextAction.type === ACCOUNT_POST_REGISTER;
      ignoreAction =
        ignoreAction || action.nextAction.type === ACCOUNT_POST_LOGIN;
      if (!ignoreAction) {
        yield put(actions.showLoadingAction(false));
      }
    }
  } else {
    let allowAction = false;
    allowAction = allowAction || action.type === ACCOUNT_POST_LOGOUT;
    allowAction = allowAction || action.type === 'INITIALIZE_FINISHED';
    allowAction = allowAction || action.type === ACCOUNT_POST_DELETE_USER;
    allowAction = allowAction || action.type === PROCESS_BACK_BUTTON_DEVICES;
    if (allowAction) {
      yield put(actions.showLoadingAction(false));
    }
  }
}

export function* showLoadingView(action: any) {
  if (action.nextAction !== undefined) {
    if (action.type === REQUEST_ERROR) {
      yield put(actions.showLoadingAction(false));
    } else {
      let ignoreAction = false;
      ignoreAction =
        ignoreAction || action.nextAction.type === 'USERS_POST_SET_PROFILE';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'UPLOAD_IMAGE_AVATAR';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'POST_CHAT_MESSAGES';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'POST_MESSAGE_GROUP_CHAT';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'FETCH_CHAT_MESSAGES';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'GROUP_ITEM_SUBSCRIBE_DONE';
      ignoreAction =
        ignoreAction || action.nextAction.type === 'PUT_GROUP_GAME';
      ignoreAction =
        ignoreAction ||
        action.nextAction.type === 'FETCH_GAME_QUESTIONS_PARTNER';

      if (ignoreAction) {
        yield put(actions.showLoadingAction(false));
      } else {
        yield put(actions.showLoadingAction(true));
      }
    }
  } else {
    yield put(actions.showLoadingAction(true));
  }
}

export default function* rootSaga() {
  yield takeLatest(REQUEST_SUCCESS, hideLoadingView);
  yield takeLatest(REQUEST_ERROR, hideLoadingView);

  yield takeLatest(INITIALIZE_FINISHED, hideLoadingView);

  yield takeLatest(ACCOUNT_POST_LOGOUT, hideLoadingView);
  yield takeLatest(ACCOUNT_POST_DELETE_USER, hideLoadingView);
  yield takeLatest(ACCOUNT_POST_LOGIN, hideLoadingView);
  yield takeLatest(ACCOUNT_POST_REGISTER, hideLoadingView);
  yield takeLatest(PROCESS_BACK_BUTTON_DEVICES, hideLoadingView);

  // show loading
  yield takeLatest(REQUEST_PROCESSING, showLoadingView);
}
