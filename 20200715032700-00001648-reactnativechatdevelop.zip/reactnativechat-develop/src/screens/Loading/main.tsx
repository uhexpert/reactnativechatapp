import React from 'react';
import {connect} from 'react-redux';
import LoadingView from 'components/LoadingView/LoadingViewAnimation';
import * as selectors from './selectors';
import * as actions from './actions';

interface Props {
  isShowLoading: boolean;
  textShow: string;
}

class LoadingScreen extends React.Component<Props> {
  public shouldComponentUpdate = (nextProps: any) => {
    const {isShowLoading, textShow} = this.props;
    let isChanged = false;
    isChanged = nextProps.isShowLoading !== isShowLoading;
    isChanged = isChanged || nextProps.textShow !== textShow;
    return isChanged;
  };

  public render() {
    const {isShowLoading, textShow} = this.props;
    return <LoadingView isShowLoading={isShowLoading} textShow={textShow} />;
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({
  isShowLoading: selectors.getIsShowLoading(state),
  textShow: selectors.getTextShow(state),
});

export default connect(mapStateToProps, actions)(LoadingScreen);
