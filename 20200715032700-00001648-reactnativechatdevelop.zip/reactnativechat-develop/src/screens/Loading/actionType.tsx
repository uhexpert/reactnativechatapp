/* eslint-disable import/prefer-default-export */
export const SHOW_LOADING = 'SHOW_LOADING'
export const CHANGE_TEXT_LOADING_SHOW = 'CHANGE_TEXT_LOADING_SHOW'