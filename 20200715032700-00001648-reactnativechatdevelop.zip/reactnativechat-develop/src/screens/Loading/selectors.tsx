interface State {
  screens: {
    loading: {
      isShowLoading: boolean;
      textShow: string;
    };
  };
}
export const getIsShowLoading = (state: State) =>
  state.screens.loading.isShowLoading;
export const getTextShow = (state: State) => state.screens.loading.textShow;
