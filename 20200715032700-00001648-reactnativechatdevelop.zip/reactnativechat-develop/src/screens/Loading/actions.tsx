import * as actionType from './actionType'
export const showLoadingAction = (data: any) => {
  return {
    type: actionType.SHOW_LOADING,
    data
  }
}