import * as actionType from './actionType';

const INITIAL_STATE = {
  isShowLoading: true,
  textShow: '',
};

const Loading = (state = INITIAL_STATE, action: any) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case actionType.SHOW_LOADING:
      newState.isShowLoading = action.data;
      break;
    case actionType.CHANGE_TEXT_LOADING_SHOW:
      newState.textShow = action.data;
      break;
    default:
      return state;
  }
  return newState;
};

export default Loading;
