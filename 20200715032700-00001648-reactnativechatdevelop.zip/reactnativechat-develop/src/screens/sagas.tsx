import {fork} from 'redux-saga/effects';
import LoadingSaga from './Loading/saga';
import LaunchSaga from './Launch/saga';
import LoginSaga from './Authentication/Login/saga';
import RegisterSaga from './Authentication/Register/saga';

export default function* rootSaga() {
  yield fork(LaunchSaga);
  yield fork(LoadingSaga);
  yield fork(LoginSaga);
  yield fork(RegisterSaga);
}
