import {combineReducers} from 'redux';
import RegisterReducer from './Register/reducer';
import LoginReducer from './Login/reducer';
import UpdateReducer from './UpdateInfo/reducer';

const Reducer = combineReducers({
  // validate: ValidatorReducer,
  register: RegisterReducer,
  login: LoginReducer,
  update: UpdateReducer,
});

export default Reducer;
