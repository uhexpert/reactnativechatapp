import {StyleSheet} from 'react-native';
import {rateWidth, rateHeight} from 'services/DeviceInfo';
import colors from 'constants/colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    // justifyContent: 'center',
  },

  form: {
    flexDirection: 'row',
    justifyContent: 'center',
  },

  formView: {
    // marginTop: 32 * rateHeight,
    width: 344 * rateWidth,
    height: 253 * rateHeight,
    paddingHorizontal: 15 * rateWidth,
    borderRadius: 4 * rateHeight,
    backgroundColor: '#ffffff',
    shadowColor: 'rgba(36, 36, 36, 0.05)',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowRadius: 15 * rateHeight,
    shadowOpacity: 1,
  },

  formTitleView: {
    marginTop: 10 * rateHeight,
    flexDirection: 'row',
  },

  formTitleText: {
    fontFamily: 'System',
    fontSize: 30 * rateHeight,
    fontWeight: 'bold',
    fontStyle: 'normal',
    lineHeight: 36 * rateHeight,
    letterSpacing: 0,
    textAlign: 'left',
    color: colors.black,
  },

  formItemInput: {
    flexDirection: 'column',
    marginTop: 40 * rateHeight,
  },

  formTitleInputText: {
    fontFamily: 'System',
    fontSize: 14 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: '#929292',
  },

  formInputText: {
    fontFamily: 'System',
    fontSize: 18 * rateHeight,
    // backgroundColor: 'red',
    borderBottomColor: '#4D80EB',
    borderBottomWidth: 1,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: colors.black,
  },

  butonSignIn: {
    marginTop: 60 * rateHeight,
    justifyContent: 'center',
    height: 50 * rateHeight,
    borderRadius: 4 * rateHeight,
    backgroundColor: '#4D80EB',
  },

  formButtonText: {
    fontSize: 14 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'center',
    color: '#ffffff',
  },

  // ************* Select image ***********
  selectImageArea: {
    height: 290 * rateHeight,
    alignItems: 'center',
  },

  iconCamera: {
    width: 40 * rateHeight,
    height: 40 * rateHeight,
    marginStart: '25%',
    marginTop: -55 * rateHeight,
    backgroundColor: '#28be2e',
    borderRadius: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },

  profileWrap: {
    marginTop: 100 * rateHeight,
    width: 128 * rateHeight,
    height: 128 * rateHeight,
    backgroundColor: '#DAD6D6',
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },

  profilepic: {
    flex: 1,
    width: null,
    alignSelf: 'stretch',
    borderRadius: 65 * rateHeight,
    borderColor: '#fff',
    borderWidth: 1 * rateHeight,
  },
});

export default styles;
