interface State {
  [Key: string]: any;
}
export const getAvatar = (state: State) =>
  state.screens.authentication.update.avatar;
export const getUserName = (state: State) =>
  state.screens.authentication.update.userName;
