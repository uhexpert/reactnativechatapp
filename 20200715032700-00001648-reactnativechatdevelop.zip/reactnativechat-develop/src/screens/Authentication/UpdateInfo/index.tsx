import React from 'react';
import {Text, View, TouchableOpacity} from 'react-native';

import styles from './styles';
import FormView from './form';
import Avatar from './avatar';

class Body extends React.PureComponent<Props> {
  public render() {
    return (
      <View style={styles.container}>
        <Avatar {...this.props} />
        <FormView {...this.props} />
      </View>
    );
  }
}

export default Body;
