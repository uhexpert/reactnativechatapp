import * as actionTypes from './actionType';

const INITIAL_STATE = {
  userName: 'USER',
  avatar:
    'https://i.pinimg.com/originals/2d/ca/2b/2dca2bbc2938c03f319def9651be7c00.jpg',
};

const Reducer = (state = INITIAL_STATE, action: any) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case actionTypes.CHANGE_USER_NAME:
      newState.userName = action.data;
      break;
    case actionTypes.CHANGE_IMAGE_FROM_CAMERA_OR_GALLERY:
      newState.avatar = action.data;
      break;
    default:
      return state;
  }
  return newState;
};

export default Reducer;
