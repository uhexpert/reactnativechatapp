import React from 'react';
import {connect} from 'react-redux';
import {Text, View, TouchableOpacity, TextInput} from 'react-native';
import * as Routes from 'navigator/routerName';
import * as actionProfileAPI from 'api/modules/Users/Profile/actions';
import * as actionImageApi from 'api/modules/Image/actions';
import * as accountSelectors from 'api/modules/Account/selectors';
import styles from './styles';
import * as selectors from './selectors';
import * as actions from './actions';
import {PROFILE} from 'constants/index';

class Main extends React.PureComponent<Props, State> {
  public updateProfile = () => {
    const {callPostSetProfile, callUploadImageAvata} = this.props;
    const {userId, userName, avatar, email} = this.props;
    callPostSetProfile({
      userId,
      [PROFILE.EMAIL]: email,
      [PROFILE.USER_NAME]: userName,
      [PROFILE.CREATE_DATE]: Date.now(),
    });

    // upload avatar
    if (avatar !== '' || avatar !== undefined) {
      callUploadImageAvata({
        uri: avatar,
        mime: 'application/octet-stream',
        userId: userId,
      });
    }
    // direct to chat list
    this.props.navigation.navigate(Routes.BOTTOM_TAB, {
      screen: Routes.CHAT_LIST,
      initial: false,
    });
  };

  public render() {
    return (
      <View style={styles.form}>
        <View style={styles.formView}>
          {/* name */}
          <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>{`Name`}</Text>
            <TextInput
              style={styles.formInputText}
              placeholder="pipong"
              onChangeText={(text) => this.props.changeUserName(text)}
              value={this.props.userName}
            />
          </View>

          <TouchableOpacity
            style={styles.butonSignIn}
            onPress={this.updateProfile}>
            <Text style={styles.formButtonText}>{`UPDATE`}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
/* @todo using :any */
const mapStateToProps = (state: any) => ({
  userId: accountSelectors.getUserId(state),
  email: accountSelectors.getUserEmail(state),
  avatar: selectors.getAvatar(state),
  userName: selectors.getUserName(state),
});

export default connect(mapStateToProps, {
  ...actionProfileAPI,
  ...actionImageApi,
  ...actions,
})(Main);
