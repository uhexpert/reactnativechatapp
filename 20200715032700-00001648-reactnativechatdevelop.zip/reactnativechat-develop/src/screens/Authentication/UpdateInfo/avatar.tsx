import React from 'react';
import {rateHeight} from 'services/DeviceInfo';
import {Image, View, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import IconEntypo from 'react-native-vector-icons/Entypo';
// import * as actionImage from 'api/modules/Image/actions';
// import * as profileActions from 'api/modules/Users/Profile/actions';
// import * as accountSelectors from 'api/modules/Account/selectors';
// import * as profileSelectors from 'api/modules/Users/Profile/selectors';
// import imageURLUser from 'screen/Assets/profile';
import styles from './styles';
import * as actions from './actions';
import * as selectors from './selectors';
// import AvatarDefault from 'assets/images/avatar.png';
import ImagePicker from 'react-native-image-picker';

// More info on all the options is below in the README...just some common use cases shown here
const options = {
  title: 'Select Avatar',
  chooseFromLibraryButtonTitle: 'Choose Photo from Library',
  takePhotoButtonTitle: 'Take camera',
  cancelButtonTitle: 'Cancel',
  storageOptions: {
    skipBackup: true,
    path: 'images',
  },
};

class Index extends React.Component {
  getImage = () => {
    const {changeImageAvatar} = this.props;
    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        // callUploadImageAvata({ uri: response.uri, mime: 'application/octet-stream', userId })
        // callPostSetDefaultProfileLocal({
        //   urlImage: response.uri
        // })
        changeImageAvatar(response.uri);
      }
    });
  };

  renderIconOrImage = () => {
    const {profileWrap, profilepic} = styles;
    return (
      <View style={profileWrap}>
        <Image style={profilepic} source={{uri: this.props.avatar}} />
      </View>
    );
  };

  render() {
    const {selectImageArea} = styles;
    const {iconCamera} = styles;
    return (
      <View style={selectImageArea}>
        {this.renderIconOrImage()}
        <TouchableOpacity style={iconCamera} onPress={this.getImage}>
          <IconEntypo name="camera" size={25 * rateHeight} color="white" />
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  avatar: selectors.getAvatar(state),
});

export default connect(mapStateToProps, {
  ...actions,
})(Index);
