import * as actionTypes from './actionType';

export const changeImageAvatar = (data: any) => {
  return {
    type: actionTypes.CHANGE_IMAGE_FROM_CAMERA_OR_GALLERY,
    data,
  };
};

export const changeUserName = (data: string) => {
  return {
    type: actionTypes.CHANGE_USER_NAME,
    data,
  };
};
