import React from 'react';
import {Text, View, TouchableOpacity, TextInput, Keyboard} from 'react-native';
import * as Routes from 'navigator/routerName';
import i18n from 'i18n';
import * as accountActions from 'api/modules/Account/actions';
import {connect} from 'react-redux';
import * as actions from './actions';
import * as selectors from './selectors';
import {EMAIL, PASSWORD} from 'constants/index';
import Error from './error';
import styles from './styles';

interface InputsObject {
  [field: string]: string;
}

interface Props {
  inputs: InputsObject;
  callRequestLogin: (providerType: string, data: object) => void;
  onChangeValue: (field: string, data: string) => void;
  showError: (field: string) => void;
  hideError: () => void;
}

class Form extends React.PureComponent<Props, State> {
  public passwordTextInput: TextInput | null | undefined;
  signUp = () => {
    const {navigation} = this.props;
    navigation.navigate(Routes.AUTHENTICATION, {
      screen: Routes.AUTH_SIGNUP,
    });
  };

  public signIn = () => {
    const {inputs} = this.props;
    const {callRequestLogin, showError} = this.props;
    let isOk = true;
    if (inputs === undefined) {
      showError(i18n.t('authen.error.inputEmailPassword'));
      return;
    }
    if (inputs[EMAIL] === undefined || inputs[EMAIL] === '') {
      isOk = false;
      showError(i18n.t('authen.error.notValidateEmail'));
    } else if (inputs[PASSWORD] === undefined || inputs[PASSWORD] === '') {
      isOk = false;
      showError(i18n.t('authen.error.inputPassword'));
    }

    if (isOk) {
      callRequestLogin('EmailPassword', {
        userName: inputs[EMAIL],
        password: inputs[PASSWORD],
      });
    }
  };

  public onChangeTextEmail = (value: string) => {
    const {onChangeValue} = this.props;
    onChangeValue(EMAIL, value);
  };

  public onChangeTextPassword = (value: string) => {
    const {onChangeValue} = this.props;
    onChangeValue(PASSWORD, value);
  };

  public render() {
    const {inputs} = this.props;
    const valueEmail = inputs[EMAIL];
    const valuePassword = inputs[PASSWORD];
    return (
      <View style={styles.form}>
        <View style={styles.formView}>
          <View style={styles.formTitleView}>
            <Text style={styles.formTitleText}>{i18n.t('app.name')}</Text>
            <TouchableOpacity onPress={this.signUp}>
              <Text style={styles.formSignUpText}>
                {i18n.t('authen.form.signUp')}
              </Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.formContinueText}>
            {i18n.t('authen.form.signInToContinue')}
          </Text>
          {/* Email */}
          <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>
              {i18n.t('authen.form.email')}
            </Text>
            <TextInput
              style={styles.formInputText}
              placeholder="pipong@gmail.com"
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              value={valueEmail}
              onChangeText={this.onChangeTextEmail}
              returnKeyType="next"
              onSubmitEditing={() => this.passwordTextInput!.focus()}
            />
          </View>
          {/* password */}
          <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>
              {i18n.t('authen.form.password')}
            </Text>
            <TextInput
              style={styles.formInputText}
              value={valuePassword}
              placeholder="********"
              onChangeText={this.onChangeTextPassword}
              secureTextEntry={true}
              autoCapitalize="none"
              ref={(input) => {
                this.passwordTextInput = input;
              }}
            />
          </View>
          <Error />
          <TouchableOpacity onPress={this.resetPassword}>
            <Text style={styles.formForgetPasswordText}>
              {i18n.t('authen.form.forgetPassword')}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.butonSignIn} onPress={this.signIn}>
            <Text style={styles.formButtonText}>
              {i18n.t('authen.form.signIn')}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({
  inputs: selectors.getInputValues(state),
});

export default connect(mapStateToProps, {
  ...actions,
  ...accountActions,
})(Form);
