import {takeLatest, put, select} from 'redux-saga/effects';
import {ACCOUNT_POST_LOGIN} from 'api/modules/Account/actionTypes';
import * as requestSelectors from 'api/selectors';
import * as statusConst from 'constants/index';
import {REQUEST_ERROR} from 'api/actionTypes';
import i18n from 'i18n';
import * as code from 'constants/code';
import {showError} from './actions';

export function* handleRequestLoginRespond(actions: {nextAction: any}) {
  const {nextAction} = actions;
  if (nextAction !== undefined && nextAction.type === ACCOUNT_POST_LOGIN) {
    const status = yield select(
      (state) => requestSelectors.getRequestStatus(state)[ACCOUNT_POST_LOGIN],
    );
    console.log('login fail ', status);

    if (status) {
      if (status.status === statusConst.STATUS_ERROR) {
        const {error} = status;
        if (error && error.code === code.USER_NOT_FOUND) {
          yield put(showError(i18n.t('authen.error.userNotFound')));
          return;
        }
        if (error && error.code === code.WRONG_PASSWORD) {
          yield put(showError(i18n.t('authen.error.passwordWrong')));
          return;
        }
        if (error && error.code === code.NETWORK_REQUEST_FAILED) {
          yield put(showError(i18n.t('authen.error.networkFail')));
          return;
        }
        if (error && error.code === code.INVALID_CREDENTIAL) {
          yield put(showError(i18n.t('authen.error.invalidCredential')));
          return;
        }
        if (error && error.code === code.OTHER_ERROR) {
          yield put(showError(i18n.t('authen.error.other')));
          return;
        }
        // Other case
        yield put(showError(i18n.t('authen.error.other')));
      }
    }
  }
}

export default function* rootSaga() {
  yield takeLatest(REQUEST_ERROR, handleRequestLoginRespond);
}
