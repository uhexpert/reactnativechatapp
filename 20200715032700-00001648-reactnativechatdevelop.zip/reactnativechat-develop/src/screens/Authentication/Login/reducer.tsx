import {combineReducers} from 'redux';
import * as actionTypes from './actionTypes';

export const INITIAL_STATE = {
  isShowError: false,
  errorMessage: '',
  inputs: {},
};

const MainReducer = (state = INITIAL_STATE, action) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case actionTypes.LOGIN_ONCHANGE_VALUE:
      // newState.inputs[action.field] = action.value
      return Object.assign({}, state, {
        inputs: {...newState.inputs, [action.field]: action.value},
      });
    // break
    case actionTypes.LOGIN_SHOW_ERROR:
      newState.isShowError = true;
      newState.errorMessage = action.message;
      break;
    case actionTypes.LOGIN_HIDE_ERROR:
      newState.isShowError = false;
      newState.errorMessage = '';
      break;
    case actionTypes.LOGIN_RESET_ALL_FIELD:
      newState.isShowError = false;
      newState.errorMessage = '';
      newState.inputs = {};
      break;
    default:
      return state;
  }
  return newState;
};

export default combineReducers({
  main: MainReducer,
});
