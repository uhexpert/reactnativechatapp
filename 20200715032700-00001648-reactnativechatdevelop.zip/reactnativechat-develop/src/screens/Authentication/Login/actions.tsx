import * as actionTypes from './actionTypes';

export const onChangeValue = (field: string, value: string) => {
  return {
    type: actionTypes.LOGIN_ONCHANGE_VALUE,
    field,
    value,
  };
};

export const showError = (message: string) => {
  return {
    type: actionTypes.LOGIN_SHOW_ERROR,
    message,
  };
};

export const hideError = () => {
  return {
    type: actionTypes.LOGIN_HIDE_ERROR,
  };
};

export const resetAllField = () => {
  return {
    type: actionTypes.LOGIN_RESET_ALL_FIELD,
  };
};
