interface State {
  [KEY: string]: any;
}

export const getInputValues = (state: State) =>
  state.screens.authentication.login.main.inputs;
export const getIsShowError = (state: State) =>
  state.screens.authentication.login.main.isShowError;
export const getErrorMessage = (state: State) =>
  state.screens.authentication.login.main.errorMessage;
