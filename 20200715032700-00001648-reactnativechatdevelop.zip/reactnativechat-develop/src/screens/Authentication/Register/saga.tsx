import {takeLatest, put, select} from 'redux-saga/effects';
import {ACCOUNT_POST_REGISTER} from 'api/modules/Account/actionTypes';
import * as requestSelectors from 'api/selectors';
import i18n from 'i18n';
import * as statusConst from 'constants/index';
import {REQUEST_ERROR} from 'api/actionTypes';
import * as code from 'constants/code';
import {showError} from './actions';

export function* handleRequestRegisterRespond(actions: {nextAction: any}) {
  const {nextAction} = actions;
  if (nextAction !== undefined && nextAction.type === ACCOUNT_POST_REGISTER) {
    const status = yield select(
      (state) =>
        requestSelectors.getRequestStatus(state)[ACCOUNT_POST_REGISTER],
    );
    if (status) {
      if (status.status === statusConst.STATUS_ERROR) {
        const {error} = status;
        if (error && error.code === code.EMAIL_ALREADY_IN_USE) {
          yield put(showError(i18n.t('authen.error.emailAlreadyUse')));
          return;
        }
        if (error && error.code === code.NETWORK_REQUEST_FAILED) {
          yield put(showError(i18n.t('authen.error.networkFail')));
          return;
        }
        if (error && error.code === code.INVALID_CREDENTIAL) {
          yield put(showError(i18n.t('authen.error.invalidCredential')));
          return;
        }
        if (error && error.code === code.INVALID_EMAIL) {
          yield put(showError(i18n.t('authen.error.invalidEmail')));
          return;
        }
        if (error && error.code === code.OTHER_ERROR) {
          yield put(showError(i18n.t('authen.error.other')));
          return;
        }
        // Other case
        yield put(showError(i18n.t('authen.error.other')));
      }
    }
  }
}

export default function* rootSaga() {
  yield takeLatest(REQUEST_ERROR, handleRequestRegisterRespond);
}
