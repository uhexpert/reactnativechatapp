interface State {
  [KEY: string]: any;
}
export const getInputValues = (state: State) =>
  state.screens.authentication.register.main.inputs;
export const getIsAgreePrivacy = (state: State) =>
  state.screens.authentication.register.main.isAgreePrivacy;
export const getIsShowError = (state: State) =>
  state.screens.authentication.register.main.isShowError;
export const getErrorMessage = (state: State) =>
  state.screens.authentication.register.main.errorMessage;
