import * as actionTypes from './actionTypes';

export const onChangeValue = (field: string, value: string) => {
  return {
    type: actionTypes.REGISTER_ONCHANGE_VALUE,
    field,
    value,
  };
};

export const showError = (message: string) => {
  return {
    type: actionTypes.REGISTER_SHOW_ERROR,
    message,
  };
};

export const hideError = () => {
  return {
    type: actionTypes.REGISTER_HIDE_ERROR,
  };
};

export const onShowHidePassword = () => {
  return {
    type: actionTypes.REGISTER_SHOW_HIDE_PASSWORD,
  };
};

export const onCheckPrivacy = () => {
  return {
    type: actionTypes.REGISTER_CHECK_PRIVACY,
  };
};

export const resetAllField = () => {
  return {
    type: actionTypes.REGISTER_RESET_ALL_FIELD,
  };
};
