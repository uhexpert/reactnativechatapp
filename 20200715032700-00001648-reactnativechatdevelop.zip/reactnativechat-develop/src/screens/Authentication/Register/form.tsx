import React from 'react';
import {Text, View, TouchableOpacity, TextInput, Keyboard} from 'react-native';
import {connect} from 'react-redux';
import i18n from 'i18n';
import * as Routes from 'navigator/routerName';
import * as accountActions from 'api/modules/Account/actions';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as actions from './actions';
import * as selectors from './selectors';
import {EMAIL, PASSWORD} from 'constants/index';
import Error from './error';
import styles from './styles';

interface InputsObject {
  [field: string]: string;
}

interface Props {
  inputs: InputsObject;
  callRequestRegister: (email: string, pass: string) => void;
  onChangeValue: (field: string, data: string) => void;
  showError: (field: string) => void;
  hideError: () => void;
}

class Form extends React.PureComponent<Props, State> {
  public passwordTextInput: TextInput | null | undefined;

  requestRegister = () => {
    const {inputs} = this.props;

    const {callRequestRegister, showError} = this.props;
    let isOk = true;
    if (inputs === undefined) {
      showError(i18n.t('authen.error.inputEmailPassword'));
      return;
    }
    if (inputs[EMAIL] === undefined || inputs[EMAIL] === '') {
      isOk = false;
      showError(i18n.t('authen.error.notValidateEmail'));
    } else if (inputs[PASSWORD] === undefined || inputs[PASSWORD] === '') {
      isOk = false;
      showError(i18n.t('authen.error.inputPassword'));
    }

    if (isOk) {
      callRequestRegister(inputs[EMAIL], inputs[PASSWORD]);
    }
  };

  public onChangeTextEmail = (value: string) => {
    const {onChangeValue} = this.props;
    onChangeValue(EMAIL, value);
  };

  public onChangeTextPassword = (value: string) => {
    const {onChangeValue} = this.props;
    onChangeValue(PASSWORD, value);
  };

  componentDidUpdate() {
    const {isLoginSuccess, navigation} = this.props;
    if (isLoginSuccess) {
      navigation.navigate(Routes.AUTHENTICATION, {
        screen: Routes.AUTH_UPDATE,
        initial: false,
      });
    }
  }

  public render() {
    const {inputs} = this.props;
    const valueEmail = inputs[EMAIL];
    const valuePassword = inputs[PASSWORD];
    return (
      <View style={styles.form}>
        <View style={styles.formView}>
          <View style={styles.formTitleView}>
            <Text style={styles.formTitleText}>
              {i18n.t('authen.form.signUp')}
            </Text>
          </View>
          {/* name */}
          {/* <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>{`Name`}</Text>
            <TextInput
              style={styles.formInputText}
              placeholder="pipong"
              onChangeText={(text) => this.setState({name: text})}
              value={this.state.name}
            />
          </View> */}
          {/* Email */}
          <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>
              {i18n.t('authen.form.email')}
            </Text>
            <TextInput
              style={styles.formInputText}
              placeholder="pipong@gmail.com"
              value={valueEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              onChangeText={this.onChangeTextEmail}
              returnKeyType="next"
              onSubmitEditing={() => this.passwordTextInput!.focus()}
            />
          </View>
          {/* password */}
          <View style={styles.formItemInput}>
            <Text style={styles.formTitleInputText}>
              {i18n.t('authen.form.password')}
            </Text>
            <TextInput
              style={styles.formInputText}
              placeholder="********"
              value={valuePassword}
              onChangeText={this.onChangeTextPassword}
              secureTextEntry={true}
              autoCapitalize="none"
              ref={(input) => {
                this.passwordTextInput = input;
              }}
            />
          </View>
          <Error />
          <TouchableOpacity
            style={styles.butonSignIn}
            onPress={this.requestRegister}>
            <Text style={styles.formButtonText}>
              {i18n.t('authen.form.signUpText')}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state: any) => ({
  inputs: selectors.getInputValues(state),
  isLoginSuccess: accountSelectors.getIsLogin(state),
});

export default connect(mapStateToProps, {
  ...actions,
  ...accountActions,
})(Form);
