import React from 'react';
import {connect} from 'react-redux';
import {View, Text} from 'react-native';
import * as actions from './actions';
import * as selectors from './selectors';
import styles from './styles';

export interface Props {
  errorText: string;
  isShowError: boolean;
  isconfig: boolean;
}

class Error extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
  }

  public render() {
    const {errorText, isShowError} = this.props;
    if (!isShowError) {
      return (
        <View>
          <Text style={styles.errorText} />
        </View>
      );
    }
    return (
      <View>
        <Text style={styles.errorText}>{errorText}</Text>
      </View>
    );
  }
}

const mapStateToProps = (state: any) => ({
  errorText: selectors.getErrorMessage(state),
  isShowError: selectors.getIsShowError(state),
});

export default connect(mapStateToProps, {...actions})(Error);
