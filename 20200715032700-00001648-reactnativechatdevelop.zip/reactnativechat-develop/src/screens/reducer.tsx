import {combineReducers} from 'redux';
import AuthenReducer from './Authentication/reducer';
import LaunchReducer from './Launch/reducer';
import LoadingReducer from './Loading/reducer';
import MessageReducer from './Message/reducer';
import SettingReducer from './Setting/reducer';

const Reducer = combineReducers({
  authentication: AuthenReducer,
  launch: LaunchReducer,
  loading: LoadingReducer,
  message: MessageReducer,
  setting: SettingReducer,
});

export default Reducer;
