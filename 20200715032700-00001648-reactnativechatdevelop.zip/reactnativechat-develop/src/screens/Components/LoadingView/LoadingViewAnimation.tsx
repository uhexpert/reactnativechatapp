import React from 'react';
import {StyleSheet, View} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';

interface Props {
  isShowLoading: boolean;
  textShow: string;
}

const styles = StyleSheet.create({
  spinnerTextStyle: {
    color: '#FFF',
  },
  container: {
    flex: 1,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});

class SpinnerLoading extends React.Component<Props> {
  public render() {
    const {isShowLoading, textShow} = this.props;
    return (
      <View style={styles.container}>
        <Spinner
          visible={isShowLoading}
          textContent={textShow}
          textStyle={styles.spinnerTextStyle}
        />
      </View>
    );
  }
}

export default SpinnerLoading;
