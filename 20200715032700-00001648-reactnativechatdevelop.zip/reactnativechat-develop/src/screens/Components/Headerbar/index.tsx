import React from 'react';
import {Text, View, TouchableOpacity} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import styles from './styles';
import {rateHeight} from 'services/DeviceInfo';

interface Props {
  label: string;
  isShowLabel: boolean;
  isShowRightButton: boolean;
  isShowLeftButton: boolean;
  backButtonPress: () => void;
  actionClick: () => void;
  iconName: string;
}

class Headerbar extends React.PureComponent<Props> {
  public render() {
    const {
      label,
      iconName,
      isShowLabel,
      isShowRightButton,
      isShowLeftButton,
    } = this.props;
    const {container, leftView, centerView, rightView} = styles;
    const {titleText} = styles;
    const renderLeftView = isShowLeftButton ? (
      <TouchableOpacity style={leftView} onPress={this.props.backButtonPress}>
        <MaterialIcons
          name="chevron-left"
          color="black"
          size={23 * rateHeight}
        />
      </TouchableOpacity>
    ) : (
      <View style={leftView} />
    );
    const renderLabel = isShowLabel ? (
      <Text style={titleText}>{label}</Text>
    ) : (
      <View />
    );
    const renderRightButton = isShowRightButton ? <View /> : <View />;
    return (
      <View style={container}>
        {renderLeftView}
        <View style={centerView}>{renderLabel}</View>
        <View style={rightView}>{renderRightButton}</View>
      </View>
    );
  }
}

export default Headerbar;
