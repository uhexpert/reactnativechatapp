import React from 'react';
import {View, StatusBar} from 'react-native';
import {connect} from 'react-redux';
import HeaderStatusBar from 'screens/Components/Headerbar';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as partnerSelectors from 'api/modules/Users/Partner/selectors';
import * as messageActionApi from 'api/modules/Message/actions';
import * as selectors from '../selectors';
import ChatView from './component/chat';
import styles from './styles';

class Chat extends React.Component<Props> {
  constructor(Props) {
    super(Props);
    this.state = {};
  }

  backButton = () => {
    const {navigation, partner, userId, room} = this.props;
    const {callUpdateMessageChat} = this.props;
    if (room !== undefined && room.name !== undefined)
      callUpdateMessageChat({userId, partnerId: partner.id, room});
    navigation.goBack();
  };

  render() {
    const {containerView, header, body} = styles;
    const {partner} = this.props;
    return (
      <View style={containerView}>
        <StatusBar
          translucent={true}
          backgroundColor="transparent"
          barStyle="dark-content"
        />
        <View style={header}>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <HeaderStatusBar
              label={partner.user_name}
              isShowLabel={true}
              isShowLeftButton={true}
              backButtonPress={this.backButton}
            />
          </View>
        </View>

        <View style={body}>
          <ChatView />
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  userId: accountSelectors.getUserId(state),
  partner: partnerSelectors.getPartner(state),
  room: selectors.getRoom(state),
});

export default connect(mapStateToProps, {...messageActionApi})(Chat);
