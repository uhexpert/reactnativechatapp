import {StyleSheet} from 'react-native';
import {rateWidth, rateHeight} from 'services/DeviceInfo';

const styles = StyleSheet.create({
  containerView: {
    flex: 1,
    backgroundColor: '#f0f4f7',
    flexDirection: 'column',
  },

  header: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    backgroundColor: '#ffffff',
    shadowColor: 'rgba(0, 0, 0, 0.3)',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 5,
    shadowOpacity: 1,
  },
  body: {
    flex: 4,
  },

  listPartnerItemName: {
    fontFamily: 'System',
    fontSize: 16 * rateHeight,
    fontWeight: 'bold',
    fontStyle: 'normal',
    textAlign: 'left',
    lineHeight: 22 * rateHeight,
    marginStart: 20 * rateHeight,
    letterSpacing: 0,
    color: 'rgba(0, 0, 0, 0.8)',
  },

  // chat component style
  chatComposerContent: {
    flex: 8,
    alignSelf: 'center',
    justifyContent: 'center',
    borderRadius: 20 * rateHeight,
    backgroundColor: '#F0F0F0',
  },
  chatComposerTextHint: {
    opacity: 0.5,
    fontFamily: 'System',
    fontSize: 15 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: '#000000',
  },
  chatComposerTextInput: {
    fontFamily: 'System',
    fontSize: 16 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    textAlign: 'left',
    letterSpacing: 0,
    color: '#000',
  },
  chatSendButtonView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatActionButtonView: {
    flex: 1,
    justifyContent: 'center',
    marginTop: 5,
    alignItems: 'center',
  },
  chatInputToolbarView: {
    flex: 1,
    flexDirection: 'row',
    paddingVertical: 10,
    height: 100,
    width: '100%',
    backgroundColor: 'red',
    justifyContent: 'center',
  },
  // chat product customize
  chatCustomView: {
    width: 300 * rateWidth,
    flexDirection: 'row',
    backgroundColor: '#faf0f1',
    borderRadius: 10 * rateHeight,
  },
  chatCustomAvatarView: {
    flex: 1,
    padding: 15 * rateHeight,
    // backgroundColor: 'red'
  },
  iconAvatar: {
    width: 80 * rateHeight,
    height: 80 * rateHeight,
  },
  chatCustomContentView: {
    flex: 3,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  chatCustomContentTitle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  chatCustomContentSub: {
    flex: 1,
    flexDirection: 'row',
  },
  chatCustomContentOrder: {
    flex: 1,
    height: 25 * rateHeight,
    borderRadius: 5 * rateHeight,
    marginHorizontal: 20 * rateWidth,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ff934f',
  },
  chatCustomContentCost: {
    flex: 1,
  },
  chatCustomContentTitleText: {
    marginLeft: 10 * rateWidth,
    fontFamily: 'System',
    fontSize: 20 * rateHeight,
    lineHeight: 25 * rateHeight,
    fontWeight: 'bold',
    fontStyle: 'normal',
    textAlign: 'left',
    letterSpacing: 0,
    color: '#707070',
  },
  chatCustomContentCostText: {
    marginLeft: 10 * rateWidth,
    alignSelf: 'flex-start',
    fontFamily: 'System',
    fontSize: 18 * rateHeight,
    lineHeight: 22 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    textAlign: 'left',
    letterSpacing: 0,
    color: 'rgba(112, 112, 112, 0.85)',
  },
  chatCustomContentOrderText: {
    // alignSelf: 'flex-start',
    fontFamily: 'System',
    fontSize: 14 * rateHeight,
    lineHeight: 16 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    textAlign: 'left',
    letterSpacing: 0,
    color: '#ffffff',
  },

  // chat customview order
  chatCustomOrderView: {
    width: 300 * rateWidth,
    height: 80 * rateHeight,
    flexDirection: 'column',
    backgroundColor: '#F1F1F1',
    borderRadius: 10 * rateHeight,
  },

  progressBarView: {
    // flex: 1
  },

  contentStatusView: {
    position: 'absolute',
    flexDirection: 'row',
  },
  // child
  leftView: {
    flex: 1,
    flexDirection: 'column',
  },

  dotLeftView: {
    flex: 1,
  },

  labelLeftView: {
    flex: 1,
  },
  // center dot
  centerView: {
    flex: 1.5,
    flexDirection: 'column',
    alignItems: 'center',
  },

  dotCenterView: {},
  labelCenterView: {},

  rightView: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'flex-end',
  },

  dotRightView: {},

  labelRightView: {},

  dotView: {
    width: 16 * rateWidth,
    height: 16 * rateWidth,
    borderRadius: 20 * rateHeight,
    backgroundColor: '#FF934F',
  },
  labelText: {
    fontFamily: 'System',
    fontSize: 12 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'center',
    color: 'rgba(0, 0, 0, 0.6)',
  },
  labelLeftText: {
    fontFamily: 'System',
    fontSize: 12 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: 'rgba(0, 0, 0, 0.6)',
  },
});

export default styles;
