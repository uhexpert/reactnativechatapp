/* eslint-disable */
import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {PROFILE} from 'constants/index';
import {
  GiftedChat,
  Send,
  Actions,
  ActionsProps,
} from 'react-native-gifted-chat';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as messageSelectors from 'api/modules/Message/selectors';
import * as partnerSelectors from 'api/modules/Users/Partner/selectors';
import * as imageActions from 'api/modules/Image/actions';
import * as messageActions from 'api/modules/Message/actions';
import * as selectors from '../../selectors';
import styles from './styles';
import {messageIdGenerator, parseMessagesArray} from '../../chatUtils';

import ImagePicker from 'react-native-image-picker';
import {rateWidth} from 'services/DeviceInfo';

class ChatComponent extends React.Component<Props> {
  componentWillMount() {
    const {roomId} = this.props;
    const {callFetchMessageChat} = this.props;
    callFetchMessageChat(roomId);
  }

  componentDidUpdate(prevProps) {
    const {imageUrl} = this.props;
    if (prevProps.imageUrl !== imageUrl) {
      const message = {};
      message._id = messageIdGenerator();
      message.createdAt = Date.now();
      message.user = this.getUserInfo();
      message.image = imageUrl;
      message.text = '';
      message.messageType = 'image';

      this.onSend([message]);
    }
  }

  onSend(messages = []) {
    const {callPostMessageChat, roomId, partner, tokenId} = this.props;
    const {messageType} = messages[0];

    messages[0].createdAt = Date.now();
    if (messageType === 'image') {
      messages[0].messageType = 'image';
    } else {
      messages[0].messageType = 'message';
    }
    const partnerName = partner[PROFILE.USER_NAME];
    const partnerAvatar = partner[PROFILE.AVATAR];
    const partnerTokenId = partner[PROFILE.FCM_TOKEN];
    callPostMessageChat({
      messages: parseMessagesArray(messages),
      tokenId,
      roomId,
      partnerName,
      partnerAvatar,
      partnerTokenId,
    });
  }

  getUserInfo = () => {
    const {name, userId, avatar} = this.props;
    return {
      _id: userId,
      name,
      avatar,
    };
  };

  handleAvatarPress = () => {};

  handleAddPicture = () => {
    const {userId} = this.props;
    const {callUploadImageSingleChat} = this.props;
    const options = {
      title: 'Select Profile Picture',
      mediaType: 'photo',
      takePhotoButtonTitle: 'Take a Photo',
      maxWidth: 256,
      maxHeight: 256,
      allowsEditing: true,
      noData: true,
    };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        const timestamp = Date.now();
        callUploadImageSingleChat({
          uri: response.uri,
          mime: 'application/octet-stream',
          userId: userId,
          timestamp,
        });
      }
    });
  };

  renderSend = (sendProps) => {
    return (
      <Send
        {...sendProps}
        containerStyle={{
          marginRight: 10,
          justifyContent: 'center',
        }}>
        <MaterialCommunityIcons
          name={`send`}
          size={25 * rateWidth}
          color={'#4D80EB'}
        />
      </Send>
    );
  };

  renderActions = (props: Readonly<ActionsProps>) => {
    return (
      <Actions
        {...props}
        icon={() => (
          <MaterialCommunityIcons
            name={`folder-multiple-image`}
            size={25 * rateWidth}
            color={'#4D80EB'}
          />
        )}
        onSend={this.handleAddPicture}
      />
    );
  };

  render() {
    const {body} = styles;
    const {messages} = this.props;
    return (
      <View style={body}>
        <GiftedChat
          messages={messages}
          onSend={(message) => this.onSend(message)}
          alwaysShowSend
          showUserAvatar
          isAnimated
          placeholder="Add new message..."
          showAvatarForEveryMessage
          onQuickReply={() => {}}
          messageIdGenerator={() => messageIdGenerator()}
          onPressAvatar={this.handleAvatarPress}
          onPressActionButton={this.handleAddPicture}
          renderActions={this.renderActions}
          renderSend={this.renderSend}
          user={this.getUserInfo()}
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  userId: accountSelectors.getUserId(state),

  roomId: selectors.getRoomId(state),
  imageUrl: selectors.getImageUrl(state),

  name: profileSelectors.getUserName(state),
  tokenId: profileSelectors.getFcmToken(state),
  email: profileSelectors.getUserEmail(state),
  avatar: profileSelectors.getUserAvatar(state),
  messages: messageSelectors.getMessages(state),

  partner: partnerSelectors.getPartner(state),
});

export default connect(mapStateToProps, {
  ...messageActions,
  ...imageActions,
})(ChatComponent);
