
import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  containerView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#f0f4f7',
    flexDirection: 'column'
  },

  header: {
    flex: 1
  },
  body: {
    flex: 8,
    backgroundColor: 'white'
  }
})
export default styles