export const getRoomId = (state) => state.screens.message.roomId;
export const getImageUrl = (state) => state.screens.message.imageUrl;
export const getimageGroupUrl = (state) => state.screens.message.imageGroupUrl;
export const getRoom = (state) => state.screens.message.room;
