import * as actions from './actionType';
import {initRoomId} from './chatUtils';

// show change chatting room
export const selectRoomChatSingle = (params) => {
  const {partnerId, userId, room} = params;
  const roomId = initRoomId(partnerId, userId);
  return {
    type: actions.SELECT_ROOM_CHAT_SINGLE,
    data: {roomId, room},
  };
};
