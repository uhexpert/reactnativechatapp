import * as actions from './actionType';

const INITIAL_STATE = {
  imageUrl: '',
  imageGroupUrl: '',
  roomId: '',
  room: {},
};

const updateRoomChat = (room, rooms) => {
  if (room === {}) return {};
  let object = {...room};
  rooms.forEach((r) => {
    if (r.partnerId === room.partnerId) object = {...r};
  });
  return object;
};

const ChattingReducer = (state = INITIAL_STATE, action) => {
  const newState = {...state};
  switch (action.type) {
    default:
      return state;
    case 'UPLOAD_IMAGE_GROUP_CHATING':
      newState.imageGroupUrl = action.data;
      break;
    case 'UPLOAD_IMAGE_SINGLE_CHATING':
      newState.imageUrl = action.data;
      break;
    case actions.SELECT_ROOM_CHAT_SINGLE:
      newState.roomId = action.data.roomId;
      newState.room = {...action.data.room};
      break;
    case 'ROOM_CHAT_SUBCRIBE_DONE':
      newState.room = updateRoomChat(newState.room, action.data);
      break;
    case 'POST_CHAT_MESSAGES':
      newState.room = Object.assign({}, newState.room, {
        messageText: action.data.text,
      });
      break;
  }
  return newState;
};
export default ChattingReducer;
