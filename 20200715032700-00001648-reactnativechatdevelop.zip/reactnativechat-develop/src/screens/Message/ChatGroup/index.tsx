import React from 'react';
import {connect} from 'react-redux';
import {View, StatusBar} from 'react-native';
import HeaderStatusBar from 'screens/Components/Headerbar';
import ChatView from './chatView';
import * as actions from '../actions';
import styles from './styles';

class Main extends React.Component<Props> {
  backButton = () => {};

  public render() {
    const {containerView, header, body} = styles;
    return (
      <View style={containerView}>
        <StatusBar
          translucent={true}
          backgroundColor="transparent"
          barStyle="dark-content"
        />
        <View style={header}>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <HeaderStatusBar
              label={`Chat Group`}
              isShowLabel={true}
              isShowLeftButton={false}
              backButtonPress={this.backButton}
            />
          </View>
        </View>

        <View style={body}>
          <ChatView />
        </View>
      </View>
    );
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({});

export default connect(mapStateToProps, {...actions})(Main);
