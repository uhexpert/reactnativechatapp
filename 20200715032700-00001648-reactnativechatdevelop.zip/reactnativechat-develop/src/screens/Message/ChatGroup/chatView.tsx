/* eslint-disable */
import React from 'react';
import {connect} from 'react-redux';
import {
  GiftedChat,
  Send,
  Actions,
  ActionsProps,
} from 'react-native-gifted-chat';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as actionImage from 'api/modules/Image/actions';
import * as messageActions from 'api/modules/Message/actions';
import * as messageSelectors from 'api/modules/Message/selectors';
import * as selectors from '../selectors';
import {messageIdGenerator} from './ultis';

import ImagePicker from 'react-native-image-picker';
import {rateWidth} from 'services/DeviceInfo';

interface Props {
  groupMessages: Array;
  name: string;
  userId: string;
  avatar: string;
  imageUrl: string;
  callPostGroupMessage: (message: Message) => void;
  callFetchGroupMessages: (object: object) => void;
  callUploadImageGroupChat: (object: object) => void;
}

interface State {
  page: number;
  refreshing: boolean;
}

interface Message {
  _id: string;
  user: object;
  createdAt: number;
  image: string;
  text: string;
  messageType: string;
}

class ChatComponent extends React.Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      refreshing: true,
    };
  }

  componentDidUpdate(prevProps) {
    const {imageUrl, groupMessages} = this.props;
    if (prevProps.imageUrl !== imageUrl) {
      const message: Message = {};
      message._id = messageIdGenerator();
      message.createdAt = Date.now();
      message.user = this.getUserInfo();
      message.image = imageUrl;
      message.text = '';
      message.messageType = 'image';

      this.onSend(message);
    }
    if (prevProps.groupMessages !== groupMessages) {
      this.setState({refreshing: false});
    }
  }

  onSend(message: Message) {
    const {callPostGroupMessage} = this.props;
    const {messageType} = message;

    message.createdAt = Date.now();
    if (messageType === 'image') {
      message.messageType = 'image';
    } else {
      message.messageType = 'message';
    }
    callPostGroupMessage(message);
  }

  handleAddPicture = () => {
    const {userId} = this.props;
    const {callUploadImageGroupChat} = this.props;
    const options = {
      title: 'Select Profile Picture',
      mediaType: 'photo',
      takePhotoButtonTitle: 'Take a Photo',
      maxWidth: 256,
      maxHeight: 256,
      allowsEditing: true,
      noData: true,
    };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        const timestamp = Date.now();
        callUploadImageGroupChat({
          uri: response.uri,
          mime: 'application/octet-stream',
          userID: userId,
          timestamp,
        });
      }
    });
  };

  getUserInfo = () => {
    const {name, userId, avatar} = this.props;
    return {
      _id: userId,
      name: name ? name : 'User',
      avatar: avatar ? avatar : 'app_icon.png',
    };
  };

  //////////// render layout ///////////////////
  loadMoreMessage = () => {
    const {callFetchGroupMessages} = this.props;
    const {groupMessages} = this.props;
    const {refreshing} = this.state;
    if (!refreshing)
      callFetchGroupMessages({
        lastMessage: groupMessages[groupMessages.length - 1],
      });
  };

  isCloseToTop({layoutMeasurement, contentOffset, contentSize}) {
    return contentSize.height - layoutMeasurement.height <= contentOffset.y;
  }
  ////////////////////////////////////////////

  renderSend = (sendProps) => {
    return (
      <Send
        {...sendProps}
        containerStyle={{
          marginRight: 10,
          justifyContent: 'center',
        }}>
        <MaterialCommunityIcons
          name={`send`}
          size={25 * rateWidth}
          color={'#4D80EB'}
        />
      </Send>
    );
  };

  renderActions = (props: Readonly<ActionsProps>) => {
    return (
      <Actions
        {...props}
        icon={() => (
          <MaterialCommunityIcons
            name={`folder-multiple-image`}
            size={25 * rateWidth}
            color={'#4D80EB'}
          />
        )}
        onSend={this.handleAddPicture}
      />
    );
  };

  render() {
    const {groupMessages} = this.props;
    return (
      <GiftedChat
        messages={groupMessages}
        onSend={(message) => this.onSend(message[0])}
        alwaysShowSend
        scrollToBottom={true}
        showUserAvatar
        // isAnimated
        placeholder="Add new message..."
        showAvatarForEveryMessage
        onQuickReply={() => {}}
        loadEarlier={this.state.refreshing}
        listViewProps={{
          scrollEventThrottle: 400,
          onScroll: ({nativeEvent}) => {
            if (this.isCloseToTop(nativeEvent)) {
              this.setState({refreshing: true});
              this.loadMoreMessage();
            }
          },
          keyboardDismissMode: 'on-drag',
        }}
        messageIdGenerator={() => messageIdGenerator()}
        // onPressAvatar={this.handleAvatarPress}
        onPressActionButton={this.handleAddPicture}
        // renderComposer={}
        renderActions={this.renderActions}
        renderSend={this.renderSend}
        //   renderCustomView={this.renderCustomView}
        user={this.getUserInfo()}
      />
    );
  }
}

const mapStateToProps = (state) => ({
  userId: accountSelectors.getUserId(state),
  tokenId: profileSelectors.getFcmToken(state),
  avatar: profileSelectors.getUserAvatar(state),
  name: profileSelectors.getUserName(state),
  imageUrl: selectors.getimageGroupUrl(state),

  groupMessages: messageSelectors.getGroupMessages(state),
});

export default connect(mapStateToProps, {...actionImage, ...messageActions})(
  ChatComponent,
);
