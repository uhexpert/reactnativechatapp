import {StyleSheet} from 'react-native';
import {rateHeight} from 'services/DeviceInfo';

const styles = StyleSheet.create({
  containerView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#f0f4f7',
    flexDirection: 'column',
  },

  header: {
    flex: 1,
  },
  body: {
    flex: 8,
    backgroundColor: 'white',
  },
  chatLoadMoreView: {
    height: 50 * rateHeight,
    backgroundColor: 'red',
    justifyContent: 'center',
  },

  loadMoreText: {
    fontFamily: 'System',
    fontSize: 15 * rateHeight,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'center',
    color: 'rgba(0, 0, 0, 0.8)',
  },
});

export default styles;
