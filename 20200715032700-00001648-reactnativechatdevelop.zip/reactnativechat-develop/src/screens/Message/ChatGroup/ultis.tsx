
import { Platform, PermissionsAndroid } from 'react-native'

/* eslint-disable */
export const messageIdGenerator = () => {
  // generates uuid.
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    let r = (Math.random() * 16) | 0, v = c == 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}
/* eslint-enable */

export const initRoomId = (userId, partnerId) => {
  const roomIds = []
  roomIds.push(userId)
  roomIds.push(partnerId)
  roomIds.sort()
  return roomIds.join('_')
}

export const checkPermission = () => {
  if (Platform.OS !== 'android') {
    return Promise.resolve(true)
  }
  const rationale = {
    title: 'Microphone Permission',
    message:
        'AudioExample needs access to your microphone so you can record audio.'
  }
  return PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    rationale
  ).then((result) => {
    console.log('Permission result:', result)
    return result === true || result === PermissionsAndroid.RESULTS.GRANTED
  })
}

export const parseMessageObject = (message) => {
  return Object.assign({}, message)
}

export const parseMessagesArray = (messages) => {
  const list = []
  messages.forEach((element) => {
    list.push(parseMessageObject(element))
  })
  return list
}