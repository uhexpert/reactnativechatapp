import React from 'react';
import {Text, View, TouchableOpacity, Image, FlatList} from 'react-native';
import {connect} from 'react-redux';
import LocalStorage from 'services/Storage';
import * as Routes from 'navigator/routerName';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as partnerActions from 'api/modules/Users/Partner/actions';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import * as profileActions from 'api/modules/Users/Profile/actions';
import * as actions from 'screens/Message/actions';
import styles from './styles';

import {rateWidth} from 'services/DeviceInfo';
import {PROFILE} from 'constants/index';

interface State {
  name: string;
}

class Main extends React.PureComponent<Props, State> {
  constructor(props) {
    super(props);
  }

  showSingleChat = (partner: any) => {
    // TODO
    const {selectRoomChatSingle, callFetchPartner} = this.props;
    const {userId} = this.props;
    // select room chat

    const data = {userId, partnerId: partner.id, room: {}};
    selectRoomChatSingle(data);
    // fetch partner profile
    callFetchPartner({partnerId: partner.id});
    this.props.navigation.navigate(Routes.CHAT_CHAT_SINGLE, {});
  };

  componentDidMount() {
    const {tokenId, userId} = this.props;
    // // save token to user
    LocalStorage.load({
      key: 'fcmtoken',
    })
      .then((token) => {
        console.log('check update token');
        const {callPostSetProfile} = this.props;
        if (!(userId === '' || userId === undefined) && token !== tokenId) {
          console.log('make new update token');
          const profile = {
            userId,
            [PROFILE.FCM_TOKEN]: token,
            [PROFILE.CREATE_DATE]: Date.now(),
          };
          callPostSetProfile(profile);
        }
      })
      .catch((error) => {
        console.log('can not token ...', error);
      });
  }

  public render() {
    const {users} = this.props;
    return (
      <View style={styles.userView}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          ItemSeparatorComponent={() => (
            <View style={{width: 15 * rateWidth}} />
          )}
          data={users}
          renderItem={({item: rowData}) => {
            return (
              <TouchableOpacity
                style={styles.userItem}
                onPress={() => this.showSingleChat(rowData)}>
                <View style={styles.avatarView1}>
                  <Image
                    source={{uri: rowData.avatar}}
                    style={styles.avatarView2}
                  />
                </View>
                <Text style={styles.name}>{rowData.user_name}</Text>
              </TouchableOpacity>
            );
          }}
          keyExtractor={(item, index) => index}
        />
      </View>
    );
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({
  userId: accountSelectors.getUserId(state),
  tokenId: profileSelectors.getFcmToken(state),
  users: profileSelectors.getUsers(state),
});

export default connect(mapStateToProps, {
  ...profileActions,
  ...partnerActions,
  ...actions,
})(Main);
