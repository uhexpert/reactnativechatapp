import React, {Component} from 'react';
import {Animated, Text, TouchableOpacity, View, Image} from 'react-native';
import {connect} from 'react-redux';
import * as Routes from 'navigator/routerName';
import moment from 'moment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {SwipeListView} from 'react-native-swipe-list-view';
import * as partnerActions from 'api/modules/Users/Partner/actions';
import * as profileActions from 'api/modules/Users/Profile/actions';
import * as messageActions from 'api/modules/Message/actions';
import * as messageSelectors from 'api/modules/Message/selectors';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as actions from 'screens/Message/actions';
import styles from './styles';

interface Props {
  rooms: any;
}

class ListMessage extends Component<Props> {
  rowSwipeAnimatedValues: any;
  constructor(props) {
    super(props);
    this.rowSwipeAnimatedValues = {};
    Array(100)
      .fill('')
      .forEach((_, i) => {
        this.rowSwipeAnimatedValues[`${i}`] = new Animated.Value(0);
      });
  }

  onSwipeValueChange = (swipeData) => {
    const {key, value} = swipeData;
    this.rowSwipeAnimatedValues[key].setValue(Math.abs(value));
  };

  deleteRow = (rowMap, rowKey) => {
    this.closeRow(rowMap, rowKey);
    const {rooms, userId} = this.props;
    const {callDeleteMessageChat} = this.props;

    const prevIndex = rooms.findIndex((item) => item.key === rowKey);

    const item = rooms[prevIndex];
    callDeleteMessageChat({userId, partnerId: item.partnerId});
  };

  closeRow = (rowMap, rowKey) => {
    if (rowMap[rowKey]) {
      rowMap[rowKey].closeRow();
    }
  };

  renderAvatarView = (url: string) => {
    const {itemAvatarView} = styles;
    return (
      <TouchableOpacity onPress={() => {}} style={itemAvatarView}>
        <Image source={{uri: url}} style={styles.itemAvatarIcon} />
      </TouchableOpacity>
    );
  };

  showChat = (rowData) => {
    const {item} = rowData;
    const {
      selectRoomChatSingle,
      callFetchPartner,
      userId,
      navigation,
    } = this.props;
    const data = {userId, partnerId: item.partnerId, room: item};
    selectRoomChatSingle(data);
    // fetch partner profile
    callFetchPartner({partnerId: item.partnerId});
    navigation.navigate(Routes.CHAT_CHAT_SINGLE, {});
  };

  renderContentMessage = (data) => {
    const {itemTextView, itemNameView, itemMessageView} = styles;
    const {
      itemNameText,
      itemMessageText,
      itemNameTextNotRead,
      itemMessageTextNotRead,
    } = styles;
    const contentText =
      data.item.messageText.length > 20
        ? `${data.item.messageText.substring(0, 20)}...`
        : data.item.messageText;
    if (!data.item.readed) {
      return (
        <TouchableOpacity
          style={itemTextView}
          onPress={() => {
            this.showChat(data);
          }}>
          <View style={itemNameView}>
            <Text style={itemNameTextNotRead}>{data.item.name}</Text>
          </View>
          <View style={itemMessageView}>
            <Text style={itemMessageTextNotRead}>{contentText}</Text>
            <Text style={itemMessageText}>{`  ${moment(
              data.item.createTime,
            ).from(Date.now())}`}</Text>
          </View>
        </TouchableOpacity>
      );
    }
    return (
      <TouchableOpacity
        style={itemTextView}
        onPress={() => {
          this.showChat(data);
        }}>
        <View style={itemNameView}>
          <Text style={itemNameText}>{data.item.name}</Text>
        </View>
        <View style={itemMessageView}>
          <Text style={itemMessageText}>{contentText}</Text>
          <Text style={itemMessageText}>{`  ${moment(data.item.createTime).from(
            Date.now(),
          )}`}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  render() {
    const {rooms} = this.props;
    return (
      <View style={styles.container}>
        <SwipeListView
          data={rooms}
          renderItem={(data, rowMap) => (
            <View style={styles.rowFront}>
              {this.renderAvatarView(data.item.avatar)}
              {this.renderContentMessage(data)}
            </View>
          )}
          renderHiddenItem={(data, rowMap) => (
            <View style={styles.rowBack}>
              <Text>{`Call`}</Text>
              <TouchableOpacity
                style={[styles.backRightBtn, styles.backRightBtnLeft]}
                onPress={(_) => this.closeRow(rowMap, data.item.key)}>
                <Text style={styles.backTextWhite}>{`Close`}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.backRightBtn, styles.backRightBtnRight]}
                onPress={(_) => this.deleteRow(rowMap, data.item.key)}>
                <Animated.View
                  style={[
                    styles.trash,
                    {
                      transform: [
                        {
                          scale: this.rowSwipeAnimatedValues[
                            data.item.key
                          ].interpolate({
                            inputRange: [45, 90],
                            outputRange: [0, 1],
                            extrapolate: 'clamp',
                          }),
                        },
                      ],
                    },
                  ]}>
                  <AntDesign name="delete" size={25} color="white" />
                </Animated.View>
              </TouchableOpacity>
            </View>
          )}
          leftOpenValue={75}
          rightOpenValue={-150}
          previewRowKey="0"
          previewOpenValue={-40}
          previewOpenDelay={3000}
          onRowDidOpen={this.onRowDidOpen}
          onSwipeValueChange={this.onSwipeValueChange}
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  userId: accountSelectors.getUserId(state),
  rooms: messageSelectors.getRooms(state),
});

export default connect(mapStateToProps, {
  ...profileActions,
  ...partnerActions,
  ...messageActions,
  ...actions,
})(ListMessage);
