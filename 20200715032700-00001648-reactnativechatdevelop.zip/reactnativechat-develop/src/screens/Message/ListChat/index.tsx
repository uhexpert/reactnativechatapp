import React from 'react';
import {View, StatusBar} from 'react-native';
import HeaderStatusBar from 'screens/Components/Headerbar';
import {connect} from 'react-redux';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import UsersView from './users';
import ListChat from './form';

import styles from './styles';
import {ScrollView} from 'react-native-gesture-handler';

class Main extends React.Component {
  backButton = () => {
    const {navigation} = this.props;
    navigation.goBack();
  };

  render() {
    const {container, header, body} = styles;
    const title = this.props.userName;
    console.log(this.props.userName);

    return (
      <View style={container}>
        <StatusBar
          translucent={true}
          backgroundColor="transparent"
          barStyle="dark-content"
        />
        <View style={header}>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <HeaderStatusBar
              label={title}
              isShowLabel={true}
              isShowLeftButton={false}
            />
          </View>
        </View>
        <ScrollView style={body}>
          <UsersView {...this.props} />
          <ListChat {...this.props} />
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  userName: profileSelectors.getUserName(state),
});

export default connect(mapStateToProps, null)(Main);
