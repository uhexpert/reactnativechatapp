import React from 'react';
import {Text, View, StatusBar} from 'react-native';
import HeaderStatusBar from 'screens/Components/Headerbar';
import styles from './styles';
import FormView from './form';
import Avatar from './avatar';

class Body extends React.PureComponent<Props> {
  backButtonPress = () => {
    const {navigation} = this.props;
    navigation.goBack();
  };
  public render() {
    const {container, header, body} = styles;

    return (
      <View style={container}>
        <StatusBar
          translucent={true}
          backgroundColor="transparent"
          barStyle="dark-content"
        />
        <View style={header}>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <HeaderStatusBar
              label={``}
              isShowLabel={false}
              isShowLeftButton={true}
              backButtonPress={this.backButtonPress}
            />
          </View>
        </View>
        <View style={body}>
          <Avatar {...this.props} />
          <FormView {...this.props} />
        </View>
      </View>
    );
  }
}

export default Body;
