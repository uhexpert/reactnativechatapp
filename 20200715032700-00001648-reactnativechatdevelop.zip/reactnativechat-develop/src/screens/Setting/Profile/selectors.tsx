interface State {
  [Key: string]: any;
}
export const getAvatar = (state: State) => state.screens.setting.profile.avatar;
export const getUserName = (state: State) =>
  state.screens.setting.profile.userName;
