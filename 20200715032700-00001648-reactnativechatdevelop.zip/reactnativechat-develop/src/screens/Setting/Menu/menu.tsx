import React from 'react';
import * as Routes from 'navigator/routerName';
import {connect} from 'react-redux';
import i18n from 'i18n';
import {Text, View, TouchableOpacity} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import AntDesign from 'react-native-vector-icons/AntDesign';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as accountActions from 'api/modules/Account/actions';
import styles from './styles';

class Body extends React.PureComponent<Props> {
  editProfile = () => {
    const {navigation} = this.props;
    navigation.navigate(Routes.MENU, {
      screen: Routes.MENU_PROFILE,
    });
  };

  Logout = () => {
    const {navigation} = this.props;
    const {providerType, callRequestLogOut} = this.props;
    callRequestLogOut(providerType, {});
    navigation.navigate(Routes.AUTHENTICATION, {
      screen: Routes.AUTH_SIGNIN,
    });
  };

  public render() {
    return (
      <View>
        <TouchableOpacity style={styles.menuView} onPress={this.editProfile}>
          <View style={styles.menuIcon}>
            <AntDesign name="edit" color={'#111111'} size={25} />
          </View>
          <View style={styles.menuTitle}>
            <Text style={styles.titleText}>
              {i18n.t('profile.editProfile')}
            </Text>
          </View>
          <View style={styles.menuButton}>
            <FontAwesome name="angle-right" color={'#000000'} size={25} />
          </View>
        </TouchableOpacity>

        {/* Log Out */}
        <TouchableOpacity style={styles.menuView} onPress={this.Logout}>
          <View style={styles.menuIcon}>
            <AntDesign name="logout" color={'#111111'} size={25} />
          </View>
          <View style={styles.menuTitle}>
            <Text style={styles.titleText}>{i18n.t('profile.logout')}</Text>
          </View>
          <View style={styles.menuButton}>
            <FontAwesome name="angle-right" color={'#000000'} size={25} />
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  providerType: accountSelectors.getProviderType(state),
});

export default connect(mapStateToProps, accountActions)(Body);
