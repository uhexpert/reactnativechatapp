import React from 'react';
import {Text, View, ScrollView} from 'react-native';
import Avatar from './avatar';
import Menu from './menu';
import styles from './styles';

class Body extends React.PureComponent<Props> {
  public render() {
    return (
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}>
        <Avatar />
        <Menu {...this.props} />
      </ScrollView>
    );
  }
}

export default Body;
