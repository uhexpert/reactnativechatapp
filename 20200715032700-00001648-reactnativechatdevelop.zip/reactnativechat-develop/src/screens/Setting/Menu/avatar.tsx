import React from 'react';
import {Text, View, Image} from 'react-native';
import {connect} from 'react-redux';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import styles from './styles';

class Body extends React.PureComponent<Props> {
  public render() {
    const {profile} = this.props;
    return (
      <View style={styles.avatarContentView}>
        <View style={styles.avatarView}>
          <Image source={{uri: profile.avatar}} style={styles.avatar} />
        </View>
        <View style={styles.nameView}>
          <Text style={styles.nameText}>{profile.user_name}</Text>
          <Text style={styles.emailText}>{profile.email}</Text>
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  profile: profileSelectors.getProfile(state),
});

export default connect(mapStateToProps, null)(Body);
