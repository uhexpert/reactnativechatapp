import React from 'react';
import {Text, View} from 'react-native';
import {connect} from 'react-redux';
import * as accountSelectors from 'api/modules/Account/selectors';
import * as profileSelectors from 'api/modules/Users/Profile/selectors';
import * as Routes from 'navigator/routerName';
import * as actions from './actions';
import * as selectors from './selectors';
import styles from './styles';

interface Props {
  isAppReady: boolean;
  isLoginSuccess: boolean;
  navigation: any;
  backButtonDevice: () => void;
  initialize: () => void;
}

class LaunchScreen extends React.Component<Props> {
  public componentDidMount() {
    const {initialize} = this.props;
    initialize();
  }

  public shouldComponentUpdate = (nextProps: any) => {
    const {isAppReady, isLoginSuccess} = this.props;
    let isChanged = false;
    isChanged = nextProps.isAppReady !== isAppReady;
    isChanged = isChanged || nextProps.isLoginSuccess !== isLoginSuccess;
    return isChanged;
  };

  public componentDidUpdate() {
    const {isAppReady, isLoginSuccess, navigation} = this.props;
    if (isAppReady && isLoginSuccess) {
      // setTimeout(() => {
      navigation.navigate(Routes.BOTTOM_TAB, {
        screen: Routes.CHAT_LIST,
        initial: false,
      });
      // }, 1000);
    } else if (isAppReady && !isLoginSuccess) {
      navigation.navigate(Routes.AUTHENTICATION, {
        screen: Routes.AUTH_SIGNIN,
        initial: false,
      });
    }
  }

  public handleBackButtonClick = () => {
    const {navigation, backButtonDevice} = this.props;
    const isGoBack = navigation.goBack();
    if (!isGoBack) {
      backButtonDevice();
    }
    return isGoBack;
  };

  public render() {
    return (
      <View style={styles.containerStyle}>
        <View style={styles.welcomeViewStyle}>
          <Text style={styles.titleStyle}>{`Loading...`}</Text>
        </View>
      </View>
    );
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({
  isAppReady: selectors.getIsAppReady(state),
  isLoginSuccess: accountSelectors.getIsLogin(state),
  profile: profileSelectors.getProfile(state),
});

export default connect(mapStateToProps, {...actions})(LaunchScreen);
