interface State {
  [Key: string]: any;
}
export const getIsAppReady = (state: State) =>
  state.screens.launch.main.isAppReady;
export const getMessageError = (state: State) =>
  state.screens.launch.main.errorMessage;
