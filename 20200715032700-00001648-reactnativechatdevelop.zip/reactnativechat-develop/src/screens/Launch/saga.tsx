import {takeLatest, put, select, call, take} from 'redux-saga/effects';
import LocalStorage from 'services/Storage';
import {
  callFetchAccountInfo,
  setStatusUserLogin,
  updateAccountWithProviderType,
} from 'api/modules/Account/actions';
import {getProviderType, getAccountInfo} from 'api/modules/Account/selectors';
import {ACCOUNT_FETCH_INFO} from 'api/modules/Account/actionTypes';
import * as messageActionApi from 'api/modules/Message/actions';
import * as accountApiActions from 'api/modules/Account/actions';
import {
  callSubscibeProfile,
  callFetchAllUsers,
} from 'api/modules/Users/Profile/actions';

import {INITIALIZE_DOING} from './actionType';
import {initializeFinished} from './actions';

const loadLocalProvider = () => {
  return new Promise((resolve) => {
    LocalStorage.load({
      key: 'providerType',
    })
      .then((data: any) => {
        resolve(data);
      })
      .catch((error: any) => {
        resolve('');
        // TODO: Log error
        console.log(error);
      });
  });
};

export function* initializeApp() {
  try {
    let providerType = yield select(getProviderType);
    if (providerType === '' || typeof providerType === 'undefined') {
      providerType = yield call(loadLocalProvider);
      yield put(updateAccountWithProviderType(providerType));
    }

    if (providerType === '') {
      yield put(initializeFinished());
    } else {
      // fetch acocunt from firebase auth with provider type
      yield put(callFetchAccountInfo(providerType, {}));
    }
  } catch (error) {
    // TODO: log to file
    console.log('initializeApp', error);
  }
}

export function* checkUserLogin() {
  // yield put(accountApiActions.callRequestLogOut('EmailPassword', {}));
  const accountInfo = yield select((state) => getAccountInfo(state));
  if (accountInfo.uid !== null && accountInfo.uid !== undefined) {
    const uid = accountInfo.uid.toString();
    yield put(setStatusUserLogin(true));
    // call profile user
    yield put(callSubscibeProfile(uid));
    // call user list
    yield put(callFetchAllUsers(uid));

    yield put(messageActionApi.callFetchRoomChat(uid.toString()));

    yield put(messageActionApi.callSubcriberGroupMessages());
  } else {
    yield put(setStatusUserLogin(false));
  }
  yield put(initializeFinished());
}

export default function* rootSaga() {
  yield takeLatest(INITIALIZE_DOING, initializeApp);
  yield takeLatest(ACCOUNT_FETCH_INFO, checkUserLogin);
}
