import {Alert, Platform} from 'react-native';
// @flow

import LocalStorage from 'services/Storage';
import messaging from '@react-native-firebase/messaging';

class FCMService {
  register = (
    onRegister: any,
    onNotification: any,
    onOpenNotification: any,
  ) => {
    this.checkPermission(onRegister);
    this.createNotificationListeners(
      onRegister,
      onNotification,
      onOpenNotification,
    );
  };

  // If the user has not already granted permissions, then you can prompt them to do so, as follows:
  getToken = (onRegister) => {
    messaging()
      .getToken()
      .then((fcmToken) => {
        console.log('fcm token ', fcmToken);
        if (fcmToken) {
          LocalStorage.save({
            key: 'fcmtoken',
            data: fcmToken,
          });
          onRegister(fcmToken);
        } else {
          console.log('user doesnt have a device token yet');
        }
      })
      .catch((error) => {
        console.log('getToken rejected', error);
      });
  };

  requestPermission = (onRegister) => {
    messaging()
      .requestPermission()
      .then(() => {
        this.getToken(onRegister);
      })
      .catch((error) => {
        console.log('permission rejected', error);
      });
  };
  // Before you are able to send and receive Cloud Messages, you need to ensure that the user has granted the correct permissions:
  checkPermission = (onRegister) => {
    messaging()
      .hasPermission()
      .then((enabled) => {
        if (!enabled) {
          this.getToken(onRegister);
        } else {
          this.requestPermission(onRegister);
        }
      })
      .catch((error) => {
        console.log('FCM permission rejected', error);
      });
  };

  registerAppWithFCM = async () => {
    if (Platform.OS === 'ios') {
      await messaging().registerDeviceForRemoteMessages();
      await messaging().setAutoInitEnabled(true);
    }
  };

  createNotificationListeners = (
    onRegister: any,
    onNotification: any,
    onOpenNotification: any,
  ) => {
    messaging().onNotificationOpenedApp((remoteMessage) => {
      console.log(
        'Notification caused app to open from background state:',
        remoteMessage.notification,
      );
      if (remoteMessage) {
        const notification = remoteMessage.notification;
        onOpenNotification(notification);
      }

      messaging()
        .getInitialNotification()
        .then((remoteMessage) => {
          if (remoteMessage) {
            console.log(
              'Notification caused app to open from quit state:',
              remoteMessage.notification,
            );

            if (remoteMessage) {
              const notification = remoteMessage.notification;
              onOpenNotification(notification);
            }
          }
        });
    });

    // Foreground state message
    this.messageListener = messaging().onMessage(async (remoteMessage) => {
      console.log('A new message arrived!', remoteMessage);

      if (remoteMessage) {
        const notification = remoteMessage.notification;
        onNotification(notification);
      }
    });
  };

  unRegisterMessage = () => {
    this.messageListener();
  };
}

export const fcmService = new FCMService();
