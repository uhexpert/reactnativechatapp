import React from 'react';
import {View} from 'react-native';
import {applyMiddleware, createStore, compose} from 'redux';
import {Provider} from 'react-redux';
import ReduxThunk from 'redux-thunk';
import createSagaMiddleware from 'redux-saga';
import {fcmService} from 'services/Notification/FCMService';
import {localNotificationService} from 'services/Notification/LocalNotificationService';
import Reducers from './reducer';
import Navigator from './navigator';
import Reactotron from './ReactotronConfig';
import Loading from 'screens/Loading/main';
import Sagas from './sagas';

/* global __DEV__ */
let store = null;
let sagaMiddleware = null;
// create the saga middleware
/** @format */
if (__DEV__) {
  sagaMiddleware = createSagaMiddleware();
  store = createStore(
    Reducers,
    compose(
      applyMiddleware(ReduxThunk, sagaMiddleware),
      Reactotron.connect().createEnhancer(),
    ),
  );
} else {
  sagaMiddleware = createSagaMiddleware();
  store = createStore(
    Reducers,
    {},
    applyMiddleware(ReduxThunk, sagaMiddleware),
  );
}

// then run the saga
sagaMiddleware.run(Sagas);

class App extends React.Component {
  onRegister = (token) => {
    console.log('[App] onRegister', token);
  };

  onNotification = (notify) => {
    const options = {
      soundName: 'default',
      playSound: true,
    };

    localNotificationService.showNotification(
      0,
      notify.title,
      notify.body,
      notify,
      options,
    );
  };

  onOpenNotification = (notify) => {
    // TODO
    console.log('[App] openNotification', notify);
  };

  componentDidMount() {
    fcmService.registerAppWithFCM();
    fcmService.register(
      this.onRegister,
      this.onNotification,
      this.onOpenNotification,
    );
    localNotificationService.configure(this.onOpenNotification);
  }

  componentWillUnmount() {
    fcmService.unRegisterMessage();
    localNotificationService.unregister();
  }

  render() {
    return (
      <Provider store={store}>
        <View style={{flex: 1, backgroundColor: 'red'}}>
          <Navigator />
          <Loading />
        </View>
      </Provider>
    );
  }
}

export default App;
