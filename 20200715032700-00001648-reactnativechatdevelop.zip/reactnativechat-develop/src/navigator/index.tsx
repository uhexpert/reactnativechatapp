import * as React from 'react';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {NavigationContainer} from '@react-navigation/native';
import * as Routers from './routerName';

import SignInScreen from 'screens/Authentication/Login';
import SignUpScreen from 'screens/Authentication/Register';
import UpdateScreen from 'screens/Authentication/UpdateInfo';
import SplashScreen from 'screens/Launch/main';
import {isDeviceIphoneX, rateHeight, rateWidth} from 'services/DeviceInfo';
import ListScreen from 'screens/Message/ListChat';
import ChatSingleScreen from 'screens/Message/ChatSingle';
import ChatGroupScreen from 'screens/Message/ChatGroup';
import SettingScreen from 'screens/Setting/Menu';
import ProfileScreen from 'screens/Setting/Profile';
// import {rateHeight, rateWidth, isDeviceIphoneX} from 'services/DeviceInfo';
import HomeIconWithBadge from './badge';
const Stack = createStackNavigator();
// Authen
function AuthenticationStack() {
  return (
    <Stack.Navigator
      mode="card"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name={Routers.AUTH_SIGNIN} component={SignInScreen} />
      <Stack.Screen name={Routers.AUTH_SIGNUP} component={SignUpScreen} />
      <Stack.Screen name={Routers.AUTH_UPDATE} component={UpdateScreen} />
    </Stack.Navigator>
  );
}

// Authen
function MenuStack() {
  return (
    <Stack.Navigator
      mode="card"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name={Routers.MENU_PROFILE} component={ProfileScreen} />
    </Stack.Navigator>
  );
}

const Tab = createBottomTabNavigator();

function TabStack() {
  return (
    <Tab.Navigator
      mode="card"
      tabBarOptions={{
        style: {
          height: isDeviceIphoneX() ? 84 * rateHeight : 60 * rateHeight,
        },
        activeTintColor: '#4D80EB',
      }}>
      <Tab.Screen
        name={Routers.CHAT_LIST}
        component={ListScreen}
        options={{
          tabBarLabel: 'Message',
          tabBarIcon: ({color}) => (
            <HomeIconWithBadge
              name="chat-processing"
              size={26 * rateWidth}
              color={color}
            />
          ),
        }}
      />
      <Tab.Screen
        name={Routers.CHAT_CHAT_GROUP}
        component={ChatGroupScreen}
        options={{
          tabBarLabel: 'Group',
          tabBarIcon: ({color}) => (
            <MaterialCommunityIcons
              name="wechat"
              color={color}
              size={26 * rateWidth}
            />
          ),
        }}
      />
      <Tab.Screen
        name={Routers.SETTING}
        component={SettingScreen}
        options={{
          tabBarLabel: 'Setting',
          tabBarIcon: ({color}) => (
            <MaterialCommunityIcons
              name="settings"
              color={color}
              size={26 * rateWidth}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={Routers.SPLASH}
        mode="card"
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name={Routers.SPLASH} component={SplashScreen} />
        <Stack.Screen
          name={Routers.AUTHENTICATION}
          component={AuthenticationStack}
        />
        <Stack.Screen
          name={Routers.CHAT_CHAT_SINGLE}
          component={ChatSingleScreen}
        />
        <Stack.Screen name={Routers.MENU} component={MenuStack} />

        <Stack.Screen name={Routers.BOTTOM_TAB} component={TabStack} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
