import * as React from 'react';
import {Text, View} from 'react-native';
import {connect} from 'react-redux';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import * as messageSelectors from 'api/modules/Message/selectors';
import {rateHeight} from 'services/DeviceInfo';
function IconWithBadge({name, badgeCount, color, size}) {
  return (
    <View style={{width: 24, height: 24, margin: 5}}>
      <MaterialCommunityIcons name={name} size={size} color={color} />
      {badgeCount > 0 && (
        <View
          style={{
            // On React Native < 0.57 overflow outside of parent will not work on Android, see https://git.io/fhLJ8
            position: 'absolute',
            right: -6,
            top: -3,
            backgroundColor: '#4D80EB',
            borderRadius: 20 * rateHeight,
            width: 14 * rateHeight,
            height: 14 * rateHeight,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{color: 'white', fontSize: 10, fontWeight: 'bold'}}>
            {badgeCount}
          </Text>
        </View>
      )}
    </View>
  );
}

class HomeIconWithBadge extends React.PureComponent<Props> {
  getMessageNotRead = () => {
    const {rooms} = this.props;
    let count = 0;
    if (rooms.length === 0) return 0;
    rooms.forEach((room) => {
      if (!room.readed) count += 1;
    });
    return count;
  };

  render() {
    const badgeCount = this.getMessageNotRead();
    const {children} = this.props;
    return (
      <IconWithBadge {...this.props} badgeCount={badgeCount}>
        {children}
      </IconWithBadge>
    );
  }
}

/* @todo using :any */
const mapStateToProps = (state: any) => ({
  rooms: messageSelectors.getRooms(state),
});

export default connect(mapStateToProps, {})(HomeIconWithBadge);
