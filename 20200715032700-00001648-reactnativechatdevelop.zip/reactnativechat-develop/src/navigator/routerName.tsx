export const BOTTOM_TAB = 'BOTTOM_TAB';
export const SPLASH = 'SPLASH';
export const HOME = 'HOME';
export const PROFILE = 'PROFILE';

export const AUTHENTICATION = 'AUTHENTICATION';
export const AUTH_SIGNUP = 'AUTH_SIGNUP';
export const AUTH_SIGNIN = 'AUTH_SIGNIN';
export const AUTH_UPDATE = 'AUTH_UPDATE';

export const TOP = 'TOP';
export const CHAT_LIST = 'CHAT_LIST';
export const CHAT_CHAT_SINGLE = 'CHAT_CHAT_SINGLE';
export const CHAT_CHAT_GROUP = 'CHAT_CHAT_GROUP';

export const SETTING = 'SETTING';
export const MENU = 'MENU';
export const MENU_PROFILE = 'MENU_PROFILE';
