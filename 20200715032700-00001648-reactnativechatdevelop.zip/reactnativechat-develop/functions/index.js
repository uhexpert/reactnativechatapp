const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp(functions.config().firebase);
/* eslint-disable */
const firestore = admin.firestore();

// Sent again noti after 10s
const DATE_HOURD = 10000;

exports.sendMessageWhenChatUpdate = functions.database
    .ref('users/{userId}/{partnerId}')
    .onWrite((change, context) => {
        // console.log('show value', context.params);
        const after = change.after.val();
        const before = change.before.val();
        if (!before || after.createTime - before.createTime > DATE_HOURD) {
            const { userId, partnerId } = context.params;
            const ref = `users/${userId}/${partnerId}`;
            return admin
                .database()
                .ref(ref)
                .once('value')
                .then((onSnap) => {
                    if (onSnap.val()) {
                        const { avatar, messageText, name, tokenId, readed } = onSnap.val();
                        const payload = {
                            notification: {
                                title: name,
                                body: `${messageText}`,
                                image: avatar,
                            },
                        };
                        // return if is user
                        if (readed) return;
                        // if is partner then send notification
                        console.log('show tokenId', tokenId);
                        return admin
                            .messaging()
                            .sendToDevice(tokenId, payload)
                            .then((res) => {
                                // console.log(`success ${res}`)
                            })
                            .catch((err) => {
                                // console.log(`error ${err}`)
                            });
                    } else {
                        // console.log('No token available')
                    }
                });
        }
    });

exports.sendMessageWhenChatGroup = functions.firestore
    .document('group_messages/{messageId}')
    .onWrite((change, context) => {
        const data = change.after.data();
        const { messageId } = context.params;
        if (data) {
            const { text, user } = data;
            const userId = data._id;
            const messageText = text;
            const title = `You received new message from group chat!`;
            const payload = {
                notification: {
                    title: title,
                    body: messageText,
                    image: '',
                },
            };
            console.log(payload);
            return firestore
                .collection(`users`)
                .get()
                .then((users) => {
                    const tokenIds = [];
                    users.forEach((doc) => {
                        if (userId !== doc.id) tokenIds.push(doc.data().fcm_token);
                    });
                    return admin
                        .messaging()
                        .sendToDevice(tokenIds, payload)
                        .then((res) => {
                            // console.log(`success ${res}`)
                        })
                        .catch((err) => {
                            // console.log(`error ${err}`)
                        });
                });
        } else {
            // console.log('No token available')
        }
    });